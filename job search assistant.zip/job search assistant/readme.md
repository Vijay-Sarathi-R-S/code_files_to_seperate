# 🎯 AI Resume Analyzer & Job Finder

[![Stars](https://img.shields.io/github/stars/yourusername/ai-resume-analyzer)](https://github.com/yourusername/ai-resume-analyzer)
[![Forks](https://img.shields.io/github/forks/yourusername/ai-resume-analyzer)](https://github.com/yourusername/ai-resume-analyzer)
[![Issues](https://img.shields.io/github/issues/yourusername/ai-resume-analyzer)](https://github.com/yourusername/ai-resume-analyzer/issues)
[![License](https://img.shields.io/github/license/yourusername/ai-resume-analyzer)](LICENSE)

## ✨ **Live Demo**
🔗 [https://your-app.railway.app](http://localhost:5000)

## 🎥 **Demo Video**
[![Watch Demo](https://img.youtube.com/vi/your-video-id/maxresdefault.jpg)](https://youtu.be/your-video-id)

## 🚀 **Features**
- **AI Resume Analysis** - Google Gemini extracts role/skills
- **💯 Real-time Resume Score** - Instant match percentage
- **🔍 Live Job Search** - SerpAPI finds real jobs (Indeed/LinkedIn)
- **📍 Location Filter** - Hyderabad, Bangalore, Remote
- **🌙 Dark Glassmorphism UI** - Modern gradient design
- **📱 Fully Responsive** - Mobile + Desktop
- **⚡ 3-Second Analysis** - Instant results

## 🎯 **How It Works**
