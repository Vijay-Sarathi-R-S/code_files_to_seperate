import os
import io
import json
from flask import Flask, request, jsonify, render_template  # ✅ render_template added
from dotenv import load_dotenv
import requests
import PyPDF2

# LangChain imports
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import JsonOutputParser
from langchain_google_genai import ChatGoogleGenerativeAI

load_dotenv()

app = Flask(__name__, template_folder='templates')  # ✅ Templates folder specified

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
SERPAPI_KEY = os.getenv("SERPAPI_KEY")

if not GEMINI_API_KEY:
    print("⚠️ GEMINI_API_KEY missing - using fallback analysis")

# LangChain Gemini
if GEMINI_API_KEY:
    llm = ChatGoogleGenerativeAI(
        model="gemini-1.5-flash",
        api_key=GEMINI_API_KEY,
        temperature=0.1,
        max_output_tokens=800,
    )
    parser = JsonOutputParser()
    
    system_template = """
Analyze this resume EXACTLY and return JSON:

{
  "role": "MOST ACCURATE job title from resume (e.g. Business Analyst, Frontend Developer)",
  "experience_level": "Intern/Junior/Mid/Senior based on years/projects",
  "skills": ["exact", "skills", "mentioned"],
  "summary": "2 sentences describing candidate",
  "job_keywords": ["3-5 keywords", "for job search"]
}

IMPORTANT: Match resume content precisely. No assumptions.
"""
    
    human_template = """
Desired role: {desired_role}

Resume:
{resume_text}
"""
    
    prompt = ChatPromptTemplate.from_messages([
        ("system", system_template),
        ("human", human_template),
    ])

def extract_text_from_pdf_bytes(pdf_bytes: bytes) -> str:
    """Extract text from PDF bytes"""
    try:
        reader = PyPDF2.PdfReader(io.BytesIO(pdf_bytes))
        text = ""
        for page in reader.pages:
            text += page.extract_text() or ""
        return text.strip()
    except Exception as e:
        print(f"PDF extraction error: {e}")
        return ""

def analyze_resume_with_langchain(resume_text: str, desired_role: str | None = None) -> dict:
    """Analyze resume using Gemini"""
    if not GEMINI_API_KEY:
        return get_fallback_analysis(resume_text)
    
    try:
        chain = prompt | llm | parser
        result = chain.invoke({
            "desired_role": desired_role or "",
            "resume_text": resume_text,
        })
        data = dict(result)
    except Exception as e:
        print(f"LangChain analysis failed: {e}")
        return get_fallback_analysis(resume_text)

    return {
        "role": data.get("role", "Professional"),
        "experience_level": data.get("experience_level", "Junior"),
        "skills": data.get("skills", []),
        "summary": data.get("summary", "Experienced professional"),
        "job_keywords": data.get("job_keywords", [])
    }

def get_fallback_analysis(resume_text: str) -> dict:
    """Smart fallback analysis"""
    resume_lower = resume_text.lower()
    if any(x in resume_lower for x in ["mba", "business", "administration"]):
        return {
            "role": "Business Operations Manager",
            "experience_level": "Junior",
            "skills": ["Leadership", "Project Management", "Communication"],
            "summary": "MBA graduate with operations experience",
            "job_keywords": ["mba jobs", "business operations", "project coordinator"]
        }
    elif any(x in resume_lower for x in ["python", "flask", "javascript", "developer"]):
        return {
            "role": "Software Developer",
            "experience_level": "Junior",
            "skills": ["Python", "Flask", "JavaScript", "Web Development"],
            "summary": "Full-stack developer with modern web skills",
            "job_keywords": ["python developer", "flask", "full stack"]
        }
    else:
        return {
            "role": "Professional",
            "experience_level": "Junior",
            "skills": ["Professional Skills"],
            "summary": "Experienced professional ready for new opportunities",
            "job_keywords": ["entry level", "junior"]
        }

def search_jobs_serpapi(role: str, keywords: list[str], city: str, country: str, remote_only: bool = False):
    """Search jobs using SerpAPI Google Jobs"""
    if not SERPAPI_KEY:
        print("SERPAPI_KEY not found, returning mock jobs")
        return get_mock_jobs(role, city)
    
    url = "https://serpapi.com/search.json"
    search_query = f"{role} {' '.join(keywords)}"
    if city:
        search_query += f" {city}"
    
    params = {
        "engine": "google_jobs",
        "q": search_query,
        "api_key": SERPAPI_KEY
    }
    
    if city:
        params["l"] = f"{city}, {country}"
    if remote_only:
        params["location"] = "Remote"
    
    try:
        r = requests.get(url, params=params, timeout=15)
        data = r.json()
    except Exception as e:
        print(f"SerpAPI error: {e}")
        return get_mock_jobs(role, city)
    
    if not r.ok or "jobs_results" not in data:
        return get_mock_jobs(role, city)
    
    jobs = []
    for item in data["jobs_results"][:10]:
        jobs.append({
            "title": item.get("title", ""),
            "company": item.get("company_name", ""),
            "location": item.get("location", ""),
            "description": item.get("description", "")[:300],
            "url": item.get("job_url", ""),
        })
    
    return jobs

def get_mock_jobs(role: str, city: str) -> list:
    """Fallback mock jobs - realistic for India"""
    return [
        {
            "title": f"Junior {role}",
            "company": "TechCorp India Pvt Ltd",
            "location": f"{city or 'Hyderabad'}, Telangana",
            "description": f"Entry-level {role.lower()} role. Freshers welcome. Python/Flask experience preferred.",
            "url": f"https://www.naukri.com/{role.lower()}-jobs"
        },
        {
            "title": f"{role} (Remote)",
            "company": "GlobalTech Solutions",
            "location": "Work from Home (India)",
            "description": f"Remote {role.lower()} position. 6+ months experience. Great for hackathon projects!",
            "url": f"https://www.linkedin.com/jobs/{role.lower()}-remote"
        },
        {
            "title": f"Trainee {role}",
            "company": "StartupHub",
            "location": "Bangalore, Karnataka",
            "description": f"Trainee program for {role.lower()}. Hackathon experience counts!",
            "url": f"https://internshala.com/{role.lower()}-internship"
        }
    ]

@app.route("/", methods=["GET"])
def index():
    """Serve frontend from templates folder"""
    return render_template("index.html")

@app.route("/analyze", methods=["POST"])
def analyze():
    """Main analysis endpoint"""
    try:
        if "resume" not in request.files:
            return jsonify({"error": "No resume file uploaded"}), 400

        file_storage = request.files["resume"]
        if file_storage.filename == "":
            return jsonify({"error": "No file selected"}), 400
        
        pdf_bytes = file_storage.read()
        if not pdf_bytes:
            return jsonify({"error": "Empty file"}), 400
        
        # Extract text
        resume_text = extract_text_from_pdf_bytes(pdf_bytes)
        if not resume_text:
            return jsonify({"error": "Could not extract text from PDF"}), 400

        # Get form data
        desired_role = request.form.get("desired_role", "").strip()
        city = request.form.get("city", "").strip()
        country = request.form.get("country", "IN").strip()
        remote_only = request.form.get("remote_only") == "on"

        # Analyze resume
        analysis = analyze_resume_with_langchain(resume_text, desired_role if desired_role else None)

        # 🔥 NEW: Calculate Resume Score
        score = 75
        if len(analysis.get('skills', [])) > 3: 
            score += 15
        if desired_role and desired_role.lower() in resume_text.lower(): 
            score += 10
        score = min(100, score)

        # Search jobs
        role_for_search = desired_role or analysis.get("role", "Professional")
        keywords = analysis.get("job_keywords") or analysis.get("skills") or []
        jobs = search_jobs_serpapi(role_for_search, keywords, city, country, remote_only)

        # Suggested locations for India
        suggested_locations = []
        if not jobs and country.lower() == "in":
            suggested_locations = ["Hyderabad", "Bangalore", "Pune", "Chennai", "Mumbai"]

        return jsonify({
            "analysis": analysis,
            "jobs": jobs,
            "suggested_locations": suggested_locations,
            "resume_score": score  # ✅ ADDED SCORE
        })

    except Exception as e:
        print(f"Analyze error: {e}")
        return jsonify({"error": f"Analysis failed: {str(e)}"}), 500

    

@app.route("/health", methods=["GET"])
def health():
    return jsonify({
        "status": "ok", 
        "gemini": bool(GEMINI_API_KEY), 
        "serpapi": bool(SERPAPI_KEY),
        "templates": True
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
