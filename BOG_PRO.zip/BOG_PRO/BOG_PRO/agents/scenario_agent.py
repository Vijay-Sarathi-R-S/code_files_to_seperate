"""
agents/scenario_agent.py – Scenario Builder Agent (token-optimised)
"""

import json, re
from langchain.prompts import ChatPromptTemplate
from langchain.schema.output_parser import StrOutputParser
from config import get_llm

SCENARIO_SYSTEM_PROMPT = """You are a world-builder for an alternate-history sandbox game.
Given ANY user description (historical, sci-fi, fantasy, geopolitical, fictional), build a starting world.

Return ONLY valid JSON — no markdown, no explanation:
{{
  "scenario": {{
    "title": "<short evocative title>",
    "setting": "<era and place>",
    "divergence_point": "<key departure from reality>",
    "current_year": "<starting year>",
    "genre": "<history|sci-fi|fantasy|geopolitics|alternate-history>",
    "summary": "<2-sentence vivid description>"
  }},
  "countries": [
    {{
      "name": "<name>",
      "capital": "<capital>",
      "government": "<government type>",
      "economy": "<economic status>",
      "military_strength": "<weak|moderate|strong|dominant>",
      "ideology": "<core values>",
      "color_code": "<hex color e.g. #8B4513>",
      "description": "<1 sentence>"
    }}
  ],
  "factions": [
    {{
      "name": "<name>",
      "type": "<political|military|religious|economic|revolutionary>",
      "influence": "<low|moderate|high|dominant>",
      "goal": "<primary goal>",
      "description": "<1 sentence>"
    }}
  ],
  "npcs": [
    {{
      "name": "<name>",
      "role": "<title/role>",
      "country": "<country>",
      "personality": "<2-3 traits>",
      "goal": "<ambition>",
      "threat_level": "<low|moderate|high|critical>"
    }}
  ],
  "world_conditions": {{
    "political_stability": "<stable|tense|volatile|in crisis>",
    "global_economy": "<thriving|growing|stagnant|declining|collapsed>",
    "dominant_ideology": "<main worldview>",
    "major_conflicts": ["<conflict>"],
    "technological_level": "<medieval|renaissance|industrial|modern|futuristic>",
    "social_climate": "<brief description>"
  }},
  "opening_chronicle": "<2 vivid paragraphs narrating this world at its starting point, in the style of an ancient historian.>"
}}

Generate 3-4 countries, 2-3 factions, 3-4 NPCs. Be creative and specific. ONLY output raw JSON."""

SCENARIO_HUMAN_PROMPT = 'Build a scenario for: "{user_input}"\nReturn ONLY valid JSON.'


class ScenarioAgent:
    def __init__(self):
        self.llm    = get_llm()
        self.prompt = ChatPromptTemplate.from_messages([
            ("system", SCENARIO_SYSTEM_PROMPT),
            ("human",  SCENARIO_HUMAN_PROMPT),
        ])
        self.chain = self.prompt | self.llm | StrOutputParser()

    def create_scenario(self, user_input: str) -> dict:
        raw = self.chain.invoke({"user_input": user_input})
        return self._parse(raw)

    @staticmethod
    def _parse(raw: str) -> dict:
        cleaned = re.sub(r"```(?:json)?", "", raw).strip()
        try:
            return json.loads(cleaned)
        except json.JSONDecodeError:
            m = re.search(r"\{.*\}", cleaned, re.DOTALL)
            if m:
                try: return json.loads(m.group())
                except: pass
        return {"error": "Failed to parse scenario", "raw": raw}
