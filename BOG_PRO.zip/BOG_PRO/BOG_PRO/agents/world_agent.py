"""
agents/world_agent.py – World State Agent (token-optimised)
"""

import json, re
from langchain.prompts import ChatPromptTemplate
from langchain.schema.output_parser import StrOutputParser
from config import get_llm

WORLD_SYSTEM_PROMPT = """You are a geopolitical analyst for an alternate-history game.
Given the current world and a new player event, compute only the CHANGED states.

Return ONLY valid JSON — no markdown, no explanation:
{{
  "countries": [
    {{
      "name": "<country>",
      "economy": "<updated>",
      "military_strength": "<updated>",
      "government": "<updated if changed>",
      "ideology": "<updated if changed>",
      "color_code": "<hex>",
      "status_change": "<1-sentence summary of what changed>"
    }}
  ],
  "factions": [
    {{
      "name": "<faction>",
      "influence": "<updated>",
      "goal": "<updated if evolved>",
      "change": "<what changed>"
    }}
  ],
  "world_conditions": {{
    "political_stability": "<updated>",
    "global_economy": "<updated>",
    "dominant_ideology": "<updated>",
    "major_conflicts": ["<updated list>"],
    "technological_level": "<updated if changed>",
    "social_climate": "<updated>"
  }},
  "geopolitical_analysis": "<2 paragraphs: how this event reshaped power and society>",
  "new_opportunities": ["<opp 1>", "<opp 2>"],
  "new_threats": ["<threat 1>", "<threat 2>"]
}}

Only include items that actually changed. ONLY output raw JSON."""

WORLD_HUMAN_PROMPT = """World Snapshot:
{world_state}

Player Event: {event_description}

Return only changed states as JSON."""


class WorldAgent:
    def __init__(self):
        self.llm    = get_llm()
        self.prompt = ChatPromptTemplate.from_messages([
            ("system", WORLD_SYSTEM_PROMPT),
            ("human",  WORLD_HUMAN_PROMPT),
        ])
        self.chain = self.prompt | self.llm | StrOutputParser()

    def update_world(self, world_state: dict, event_description: str) -> dict:
        state_summary = self._summarise(world_state)
        raw = self.chain.invoke({"world_state": state_summary, "event_description": event_description})
        return self._parse(raw)

    @staticmethod
    def _summarise(state: dict) -> str:
        sc = state.get("scenario", {})
        wc = state.get("world_conditions", {})
        countries = state.get("countries", [])
        lines = [
            f"Scenario: {sc.get('title')} | Year: {sc.get('current_year')}",
            f"Setting: {sc.get('setting')} | Divergence: {sc.get('divergence_point')}",
            f"Stability: {wc.get('political_stability')} | Economy: {wc.get('global_economy')}",
            f"Conflicts: {', '.join(wc.get('major_conflicts',[]))}",
            "Countries: " + "; ".join(
                f"{c.get('name')} ({c.get('government')}, {c.get('military_strength')})"
                for c in countries[:4]
            ),
        ]
        return "\n".join(lines)

    @staticmethod
    def _parse(raw: str) -> dict:
        cleaned = re.sub(r"```(?:json)?", "", raw).strip()
        try: return json.loads(cleaned)
        except:
            m = re.search(r"\{.*\}", cleaned, re.DOTALL)
            if m:
                try: return json.loads(m.group())
                except: pass
        return {"error": "Failed to parse world update", "raw": raw}
