"""
agents/consequence_agent.py – Consequence Simulation Agent (token-optimised)
"""

import json, re
from langchain.prompts import ChatPromptTemplate
from langchain.schema.output_parser import StrOutputParser
from config import get_llm

CONSEQUENCE_SYSTEM_PROMPT = """You are a historical consequence analyst for an alternate-history sandbox.
Given an event, trace its ripple effects across short, medium, and long time horizons.

Return ONLY valid JSON — no markdown, no explanation:
{{
  "event_analysed": "<event name>",
  "immediate_consequences": {{
    "political": "<within 1 year>",
    "economic": "<within 1 year>",
    "military": "<within 1 year>",
    "social": "<within 1 year>"
  }},
  "medium_term": {{
    "timeframe": "10 years",
    "key_developments": ["<dev 1>", "<dev 2>", "<dev 3>"],
    "winners": ["<winner>"],
    "losers": ["<loser>"],
    "narrative": "<2 paragraphs summarising the next decade>"
  }},
  "long_term": {{
    "timeframe": "50+ years",
    "civilisational_impact": "<how this reshapes civilisation>",
    "possible_futures": [
      {{"name": "<future 1>", "probability": "<low|moderate|high>", "description": "<1 sentence>"}},
      {{"name": "<future 2>", "probability": "<low|moderate|high>", "description": "<1 sentence>"}}
    ],
    "butterfly_effects": ["<unexpected consequence 1>", "<unexpected consequence 2>"]
  }},
  "player_opportunities": ["<action 1>", "<action 2>"]
}}

Be creative, rigorous, and surprising. ONLY output raw JSON."""

CONSEQUENCE_HUMAN_PROMPT = """Context: {world_context}
Event: {event_description}
Generate consequence cascade as JSON."""


class ConsequenceAgent:
    def __init__(self):
        self.llm    = get_llm()
        self.prompt = ChatPromptTemplate.from_messages([
            ("system", CONSEQUENCE_SYSTEM_PROMPT),
            ("human",  CONSEQUENCE_HUMAN_PROMPT),
        ])
        self.chain = self.prompt | self.llm | StrOutputParser()

    def simulate_consequences(self, world_state: dict, event_description: str) -> dict:
        raw = self.chain.invoke({
            "world_context":     self._context(world_state),
            "event_description": event_description,
        })
        return self._parse(raw)

    @staticmethod
    def _context(s: dict) -> str:
        sc = s.get("scenario", {}); wc = s.get("world_conditions", {})
        return (f"{sc.get('title')} | Year {sc.get('current_year')} | "
                f"{sc.get('setting')} | Divergence: {sc.get('divergence_point')} | "
                f"Tech: {wc.get('technological_level')} | "
                f"Economy: {wc.get('global_economy')}")

    @staticmethod
    def _parse(raw: str) -> dict:
        cleaned = re.sub(r"```(?:json)?", "", raw).strip()
        try: return json.loads(cleaned)
        except:
            m = re.search(r"\{.*\}", cleaned, re.DOTALL)
            if m:
                try: return json.loads(m.group())
                except: pass
        return {"error": "Failed to parse consequences", "raw": raw}
