"""
agents/historian_agent.py – Historian Narrator Agent (token-optimised)
"""

import json, re
from langchain.prompts import ChatPromptTemplate
from langchain.schema.output_parser import StrOutputParser
from config import get_llm

HISTORIAN_SYSTEM_PROMPT = """You are CHRONICLER — an omniscient historian recording alternate history
in rich, archaic prose (think Thucydides meets Gibbon). Write vivid, dramatic, period-appropriate narrative.

Return ONLY valid JSON — no markdown, no explanation:
{{
  "chronicle_title": "<evocative title for this entry>",
  "chronicle_entry": "<2-3 dramatic paragraphs narrating the events. Use archaic-flavoured but readable prose. Reference specific figures, nations, and consequences by name. 200-350 words.>",
  "historical_verdict": "<one memorable sentence: the historian's verdict on this moment>",
  "era_name": "<poetic name for this period, e.g. 'The Age of Iron Crowns'>",
  "notable_quote": {{
    "speaker": "<a figure's name>",
    "quote": "<a dramatic in-character quote>"
  }}
}}

ONLY output raw JSON."""

HISTORIAN_HUMAN_PROMPT = """World: {world_summary}
Events: {events}
NPC Actions: {npc_actions}
Type: {chronicle_type}

Write the chronicle entry as JSON."""


class HistorianAgent:
    def __init__(self):
        self.llm    = get_llm()
        self.prompt = ChatPromptTemplate.from_messages([
            ("system", HISTORIAN_SYSTEM_PROMPT),
            ("human",  HISTORIAN_HUMAN_PROMPT),
        ])
        self.chain = self.prompt | self.llm | StrOutputParser()

    def narrate(self, world_state: dict, events: list, npc_actions: dict = None, chronicle_type: str = "event") -> dict:
        raw = self.chain.invoke({
            "world_summary":  self._summary(world_state),
            "events":         self._fmt_events(events),
            "npc_actions":    self._fmt_npc(npc_actions),
            "chronicle_type": chronicle_type,
        })
        return self._parse(raw)

    @staticmethod
    def _summary(s: dict) -> str:
        sc = s.get("scenario", {}); wc = s.get("world_conditions", {})
        return (f"{sc.get('title')} | Year {sc.get('current_year')} | Turn {s.get('turn',0)} | "
                f"Stability: {wc.get('political_stability')} | Tech: {wc.get('technological_level')}")

    @staticmethod
    def _fmt_events(events: list) -> str:
        if not events: return "World continues on its natural course."
        return "; ".join(f"{e.get('name','?')}: {e.get('description','')}" for e in events[-3:])

    @staticmethod
    def _fmt_npc(npc_actions: dict) -> str:
        if not npc_actions or "npc_decisions" not in npc_actions: return "None."
        return "; ".join(
            f"{d.get('npc_name')} — {d.get('decision')}"
            for d in npc_actions.get("npc_decisions", [])[:3]
        )

    @staticmethod
    def _parse(raw: str) -> dict:
        cleaned = re.sub(r"```(?:json)?", "", raw).strip()
        try: return json.loads(cleaned)
        except:
            m = re.search(r"\{.*\}", cleaned, re.DOTALL)
            if m:
                try: return json.loads(m.group())
                except: pass
        return {"error": "Failed to parse chronicle", "raw": raw}
