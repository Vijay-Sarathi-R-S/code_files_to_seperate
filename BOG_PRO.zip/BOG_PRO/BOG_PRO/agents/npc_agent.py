"""
agents/npc_agent.py – NPC Decision Agent (token-optimised)
"""

import json, re
from langchain.prompts import ChatPromptTemplate
from langchain.schema.output_parser import StrOutputParser
from config import get_llm

NPC_SYSTEM_PROMPT = """You are an NPC decision engine for an alternate-history sandbox game.
Simulate how historical figures and leaders respond to world events based on their personality and goals.

Return ONLY valid JSON — no markdown, no explanation:
{{
  "npc_decisions": [
    {{
      "npc_name": "<name>",
      "role": "<role>",
      "country": "<country>",
      "decision": "<specific action they take>",
      "reasoning": "<1-2 sentences from their perspective>",
      "impact": "<immediate impact on the world>",
      "dialogue": "<a dramatic in-character quote>",
      "mood": "<triumphant|confident|anxious|desperate|cunning|furious|calculating>",
      "next_likely_action": "<hint at next move>"
    }}
  ],
  "emergent_event": {{
    "title": "<unexpected event title>",
    "description": "<1-2 sentences>",
    "severity": "<minor|moderate|major|catastrophic>"
  }}
}}

Include 2-4 NPCs who would react to the current events. Make decisions feel authentic and surprising.
ONLY output raw JSON."""

NPC_HUMAN_PROMPT = """World: {world_summary}
Recent Events: {recent_events}
NPCs: {npc_roster}

Generate NPC decisions as JSON."""


class NPCAgent:
    def __init__(self):
        self.llm    = get_llm()
        self.prompt = ChatPromptTemplate.from_messages([
            ("system", NPC_SYSTEM_PROMPT),
            ("human",  NPC_HUMAN_PROMPT),
        ])
        self.chain = self.prompt | self.llm | StrOutputParser()

    def get_npc_actions(self, world_state: dict, recent_events: list) -> dict:
        raw = self.chain.invoke({
            "world_summary":  self._summary(world_state),
            "recent_events":  self._fmt_events(recent_events),
            "npc_roster":     self._fmt_npcs(world_state.get("npcs", [])),
        })
        return self._parse(raw)

    @staticmethod
    def _summary(s: dict) -> str:
        sc = s.get("scenario", {}); wc = s.get("world_conditions", {})
        return (f"{sc.get('title')} | Year {sc.get('current_year')} | "
                f"Stability: {wc.get('political_stability')} | "
                f"Conflicts: {', '.join(wc.get('major_conflicts', []))}")

    @staticmethod
    def _fmt_events(events: list) -> str:
        if not events: return "No notable events."
        return "; ".join(f"{e.get('name','?')}: {e.get('description','')}" for e in events[-3:])

    @staticmethod
    def _fmt_npcs(npcs: list) -> str:
        if not npcs: return "No NPCs."
        return "\n".join(
            f"- {n.get('name')} ({n.get('role')}, {n.get('country')}): goal={n.get('goal')}; traits={n.get('personality')}"
            for n in npcs[:5]
        )

    @staticmethod
    def _parse(raw: str) -> dict:
        cleaned = re.sub(r"```(?:json)?", "", raw).strip()
        try: return json.loads(cleaned)
        except:
            m = re.search(r"\{.*\}", cleaned, re.DOTALL)
            if m:
                try: return json.loads(m.group())
                except: pass
        return {"error": "Failed to parse NPC decisions", "raw": raw}
