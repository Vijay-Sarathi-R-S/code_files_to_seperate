import ast, sys
files = [
    'd:/BOG_PRO/app.py',
    'd:/BOG_PRO/config.py',
    'd:/BOG_PRO/orchestrator.py',
    'd:/BOG_PRO/routes/api.py',
    'd:/BOG_PRO/agents/scenario_agent.py',
    'd:/BOG_PRO/agents/world_agent.py',
    'd:/BOG_PRO/agents/npc_agent.py',
    'd:/BOG_PRO/agents/consequence_agent.py',
    'd:/BOG_PRO/agents/historian_agent.py',
]
ok = True
for f in files:
    try:
        ast.parse(open(f).read())
        print(f'OK  {f}')
    except SyntaxError as e:
        print(f'ERR {f} -> {e}')
        ok = False
print('\nALL OK' if ok else '\nERRORS FOUND')
sys.exit(0 if ok else 1)
