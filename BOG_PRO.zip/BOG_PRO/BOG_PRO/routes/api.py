"""
routes/api.py – All Flask REST API routes.
Each route delegates to the AgentOrchestrator and returns JSON.
"""

from flask import Blueprint, request, jsonify
from orchestrator import orchestrator
from world_state  import world_state
import config as _config

api_bp = Blueprint("api", __name__, url_prefix="/api")


def _err(message: str, status: int = 400):
    return jsonify({"success": False, "error": message}), status


def _handle_exc(exc: Exception):
    msg = str(exc)
    if "NO_API_KEY" in msg or "GEMINI_API_KEY" in msg or isinstance(exc, EnvironmentError):
        return jsonify({
            "success": False,
            "error": "NO_API_KEY",
            "message": "No valid Gemini API key is set. Use the ⚙ Settings button to enter your key.",
        }), 503
    if "API_KEY_INVALID" in msg or "API key not valid" in msg:
        return jsonify({
            "success": False,
            "error": "API_KEY_INVALID",
            "message": "Your Gemini API key was rejected by Google. "
                       "Please get a fresh key from aistudio.google.com/apikey and enter it via ⚙ Settings.",
        }), 503
    return jsonify({"success": False, "error": msg}), 500


# ------------------------------------------------------------------
# API Key Configuration (no auth needed — just runtime memory)
# ------------------------------------------------------------------

@api_bp.route("/config/setkey", methods=["POST"])
def set_api_key():
    """POST /api/config/setkey — { "api_key": "AIza..." }
    Stores the key in memory for this server session.
    """
    data = request.get_json(silent=True) or {}
    key  = data.get("api_key", "").strip()
    if not key:
        return _err("'api_key' is required.")
    _config.set_runtime_key(key)
    return jsonify({"success": True, "message": "API key updated. Ready to forge worlds!"})


@api_bp.route("/config/status", methods=["GET"])
def get_config_status():
    """GET /api/config/status — Check if a key is configured."""
    key = _config.get_api_key()
    has_key = bool(key and key != "paste_your_gemini_api_key_here")
    return jsonify({"success": True, "has_key": has_key,
                    "key_preview": f"{key[:8]}…" if has_key else "none"})





# ------------------------------------------------------------------
# Scenario Management
# ------------------------------------------------------------------

@api_bp.route("/scenario/create", methods=["POST"])
def create_scenario():
    """
    POST /api/scenario/create
    Body: { "user_input": "... free-text description ..." }
    Initialises a brand-new alternate-history world.
    """
    data = request.get_json(silent=True) or {}
    user_input = data.get("user_input", "").strip()
    if not user_input:
        return _err("'user_input' is required.")

    try:
        result = orchestrator.create_scenario(user_input)
        status = 200 if result.get("success") else 500
        return jsonify(result), status
    except Exception as exc:
        return _handle_exc(exc)


@api_bp.route("/world/reset", methods=["POST"])
def reset_world():
    """Reset the world state completely."""
    world_state.reset()
    return jsonify({"success": True, "message": "World state has been reset."})


# ------------------------------------------------------------------
# World State
# ------------------------------------------------------------------

@api_bp.route("/world/state", methods=["GET"])
def get_world_state():
    """GET /api/world/state — Full current world snapshot."""
    if not world_state.is_initialized():
        return jsonify({
            "success": False,
            "initialized": False,
            "message": "No scenario created yet.",
        })
    return jsonify({
        "success": True,
        "initialized": True,
        "state": world_state.get_snapshot(),
    })


# ------------------------------------------------------------------
# Events
# ------------------------------------------------------------------

@api_bp.route("/event/apply", methods=["POST"])
def apply_event():
    """
    POST /api/event/apply
    Body: { "event_name": "...", "event_description": "..." }
    Applies a player-defined historical change and runs all 5 agents.
    """
    if not world_state.is_initialized():
        return _err("No scenario created yet. Create a scenario first.")

    data = request.get_json(silent=True) or {}
    event_name        = data.get("event_name", "").strip()
    event_description = data.get("event_description", "").strip()

    if not event_name or not event_description:
        return _err("'event_name' and 'event_description' are required.")

    try:
        result = orchestrator.apply_event(event_name, event_description)
        status = 200 if result.get("success") else 500
        return jsonify(result), status
    except Exception as exc:
        return _handle_exc(exc)


# ------------------------------------------------------------------
# What-If Simulation
# ------------------------------------------------------------------

@api_bp.route("/whatif", methods=["POST"])
def simulate_what_if():
    """
    POST /api/whatif
    Body: { "question": "What if Napoleon won at Waterloo?" }
    Pure simulation — does NOT modify world state.
    """
    if not world_state.is_initialized():
        return _err("No scenario created yet. Create a scenario first.")

    data     = request.get_json(silent=True) or {}
    question = data.get("question", "").strip()
    if not question:
        return _err("'question' is required.")

    try:
        result = orchestrator.simulate_what_if(question)
        return jsonify(result)
    except Exception as exc:
        return _handle_exc(exc)


# ------------------------------------------------------------------
# NPC Actions
# ------------------------------------------------------------------

@api_bp.route("/npc/actions", methods=["POST"])
def get_npc_actions():
    """
    POST /api/npc/actions
    Returns autonomous NPC decisions without modifying world state.
    """
    if not world_state.is_initialized():
        return _err("No scenario created yet. Create a scenario first.")

    try:
        result = orchestrator.get_npc_decisions()
        return jsonify(result)
    except Exception as exc:
        return _handle_exc(exc)


# ------------------------------------------------------------------
# Turn Advancement
# ------------------------------------------------------------------

@api_bp.route("/turn/advance", methods=["POST"])
def advance_turn():
    """
    POST /api/turn/advance
    Body: { "years": 5 }  (default: 1)
    Advances the timeline by N years.
    """
    if not world_state.is_initialized():
        return _err("No scenario created yet. Create a scenario first.")

    data  = request.get_json(silent=True) or {}
    years = int(data.get("years", 1))
    if years < 1 or years > 100:
        return _err("'years' must be between 1 and 100.")

    try:
        result = orchestrator.advance_turn(years)
        status = 200 if result.get("success") else 500
        return jsonify(result), status
    except Exception as exc:
        return _handle_exc(exc)


# ------------------------------------------------------------------
# Factions & Chronicle (convenience endpoints)
# ------------------------------------------------------------------

@api_bp.route("/factions", methods=["GET"])
def get_factions():
    """GET /api/factions — List current factions."""
    state = world_state.get_snapshot()
    return jsonify({"success": True, "factions": state.get("factions", [])})


@api_bp.route("/chronicle", methods=["GET"])
def get_chronicle():
    """GET /api/chronicle — Full chronicle history."""
    return jsonify({
        "success": True,
        "chronicle": world_state.get_chronicle(),
        "turn": world_state.get_turn(),
    })


@api_bp.route("/npcs", methods=["GET"])
def get_npcs():
    """GET /api/npcs — List current NPCs."""
    state = world_state.get_snapshot()
    return jsonify({"success": True, "npcs": state.get("npcs", [])})
