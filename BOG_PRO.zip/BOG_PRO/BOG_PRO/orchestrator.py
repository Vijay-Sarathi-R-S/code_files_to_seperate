"""
orchestrator.py – Multi-Agent Orchestrator
Coordinates all 5 LangChain agents in a sequential pipeline to respond to:
  - Scenario creation
  - Player-applied events
  - What-if queries
  - Turn advancement
  - Autonomous NPC decisions
"""

from agents.scenario_agent    import ScenarioAgent
from agents.world_agent       import WorldAgent
from agents.npc_agent         import NPCAgent
from agents.consequence_agent import ConsequenceAgent
from agents.historian_agent   import HistorianAgent
from world_state              import world_state


class AgentOrchestrator:
    """
    Coordinates all 5 agents in structured pipelines.

    Pipelines:
      create_scenario  → ScenarioAgent → WorldState.initialize → NPCAgent (opening) → HistorianAgent
      apply_event      → WorldAgent → ConsequenceAgent → NPCAgent → HistorianAgent → WorldState.apply
      simulate_what_if → ConsequenceAgent → HistorianAgent (no state change)
      advance_turn     → NPCAgent → WorldAgent → HistorianAgent → WorldState.advance
    """

    def __init__(self):
        self.scenario_agent    = ScenarioAgent()
        self.world_agent       = WorldAgent()
        self.npc_agent         = NPCAgent()
        self.consequence_agent = ConsequenceAgent()
        self.historian_agent   = HistorianAgent()

    # ------------------------------------------------------------------
    # Pipeline 1: Create a new scenario
    # ------------------------------------------------------------------
    def create_scenario(self, user_input: str) -> dict:
        """
        Full pipeline: user description → scenario data → world init → opening chronicle.
        """
        # 1. Scenario Agent: build the world from user input
        scenario_data = self.scenario_agent.create_scenario(user_input)
        if "error" in scenario_data:
            return {"success": False, "error": scenario_data["error"]}

        # 2. Initialise the world state
        world_state.initialize(scenario_data)

        # 3. Historian Agent: compose opening chronicle entry
        state_snapshot = world_state.get_snapshot()
        history = self.historian_agent.narrate(
            world_state=state_snapshot,
            events=[],
            npc_actions=None,
            chronicle_type="opening",
        )
        if "chronicle_entry" in history:
            world_state.apply_change({
                "chronicle_entry": history.get("chronicle_entry"),
                "chronicle_type": "opening",
            })

        return {
            "success": True,
            "scenario": scenario_data.get("scenario", {}),
            "world": world_state.get_snapshot(),
            "opening_chronicle": history,
        }

    # ------------------------------------------------------------------
    # Pipeline 2: Apply a player-defined historical event
    # ------------------------------------------------------------------
    def apply_event(self, event_name: str, event_description: str) -> dict:
        """
        Full pipeline: player event → world update → consequences → NPC reactions → chronicle.
        """
        state_snapshot  = world_state.get_snapshot()
        full_description = f"{event_name}: {event_description}"

        # 1. World Agent: compute geopolitical changes
        world_update = self.world_agent.update_world(state_snapshot, full_description)

        # 2. Consequence Agent: compute ripple effects
        consequences = self.consequence_agent.simulate_consequences(
            state_snapshot, full_description
        )

        # 3. NPC Agent: autonomous NPC reactions
        new_event = {
            "name": event_name,
            "description": event_description,
            "turn": world_state.get_turn() + 1,
        }
        npc_actions = self.npc_agent.get_npc_actions(
            state_snapshot,
            [new_event],
        )

        # 4. Historian Agent: narrate the events
        history = self.historian_agent.narrate(
            world_state=state_snapshot,
            events=[new_event],
            npc_actions=npc_actions,
            chronicle_type="event",
        )

        # 5. Apply all changes to the world state
        change_data = {
            "events": [{
                "name": event_name,
                "description": event_description,
                "consequences_summary": (
                    consequences.get("immediate_consequences", {})
                    if isinstance(consequences, dict) else {}
                ),
            }],
            "chronicle_entry": history.get("chronicle_entry", ""),
            "chronicle_type": "event",
        }
        if isinstance(world_update, dict):
            change_data["countries"]       = world_update.get("countries", [])
            change_data["factions"]        = world_update.get("factions", [])
            change_data["world_conditions"] = world_update.get("world_conditions", {})

        world_state.apply_change(change_data)

        return {
            "success": True,
            "world_update": world_update,
            "consequences": consequences,
            "npc_actions": npc_actions,
            "chronicle": history,
            "current_state": world_state.get_snapshot(),
        }

    # ------------------------------------------------------------------
    # Pipeline 3: What-if simulation (no state change)
    # ------------------------------------------------------------------
    def simulate_what_if(self, what_if_question: str) -> dict:
        """
        Explores a hypothetical scenario without modifying the world state.
        """
        state_snapshot = world_state.get_snapshot()

        # Consequence Agent: explore the hypothetical
        consequences = self.consequence_agent.simulate_consequences(
            state_snapshot, f"[HYPOTHETICAL] {what_if_question}"
        )

        # Historian Agent: narrate the hypothetical as a speculative chronicle
        history = self.historian_agent.narrate(
            world_state=state_snapshot,
            events=[{"name": "What-If Scenario", "description": what_if_question}],
            npc_actions=None,
            chronicle_type="what_if",
        )

        return {
            "success": True,
            "question": what_if_question,
            "consequences": consequences,
            "speculative_chronicle": history,
        }

    # ------------------------------------------------------------------
    # Pipeline 4: Advance the timeline by N years
    # ------------------------------------------------------------------
    def advance_turn(self, years: int = 1) -> dict:
        """
        Advances the world by N years: NPCs act → world evolves → historian narrates.
        """
        state_snapshot = world_state.get_snapshot()

        # 1. NPC Agent: autonomous actions during the time skip
        npc_actions = self.npc_agent.get_npc_actions(
            state_snapshot,
            state_snapshot.get("events", [])[-3:],
        )

        # 2. World Agent: simulate organic world evolution
        time_event = f"The world advances {years} year(s) under its own momentum."
        world_update = self.world_agent.update_world(state_snapshot, time_event)

        # 3. Historian Agent: narrate the era
        history = self.historian_agent.narrate(
            world_state=state_snapshot,
            events=[{"name": f"{years} Year(s) Pass", "description": time_event}],
            npc_actions=npc_actions,
            chronicle_type="turn_advance",
        )

        # 4. Advance world state
        change_data = {
            "chronicle_entry": history.get("chronicle_entry", ""),
            "chronicle_type": "turn_advance",
        }
        if isinstance(world_update, dict):
            change_data["countries"]       = world_update.get("countries", [])
            change_data["factions"]        = world_update.get("factions", [])
            change_data["world_conditions"] = world_update.get("world_conditions", {})

        world_state.advance_turn(years, change_data)

        return {
            "success": True,
            "years_advanced": years,
            "npc_actions": npc_actions,
            "world_update": world_update,
            "chronicle": history,
            "current_state": world_state.get_snapshot(),
        }

    # ------------------------------------------------------------------
    # Pipeline 5: Get standalone NPC decisions (no state change)
    # ------------------------------------------------------------------
    def get_npc_decisions(self) -> dict:
        """Get current autonomous NPC decisions without applying them."""
        state_snapshot = world_state.get_snapshot()
        npc_actions = self.npc_agent.get_npc_actions(
            state_snapshot,
            state_snapshot.get("events", [])[-3:],
        )
        return {
            "success": True,
            "npc_actions": npc_actions,
        }


# Singleton orchestrator instance
orchestrator = AgentOrchestrator()
