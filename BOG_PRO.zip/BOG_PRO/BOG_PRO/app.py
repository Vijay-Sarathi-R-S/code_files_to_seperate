"""
app.py – Flask application entry point with session-based login.
Credentials: admin / admin
"""

from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from flask_cors import CORS
from routes.api import api_bp
from config import FLASK_PORT, FLASK_DEBUG
import functools

app = Flask(__name__)
app.secret_key = "codex-alternus-secret-2024"
CORS(app)

# ── Auth ──────────────────────────────────────────────────────────
VALID_USERS = {"admin": "admin"}

def login_required(f):
    @functools.wraps(f)
    def decorated(*args, **kwargs):
        if not session.get("logged_in"):
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated

@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()
        if VALID_USERS.get(username) == password:
            session["logged_in"] = True
            session["username"]  = username
            return redirect(url_for("index"))
        error = "Invalid username or password."
    return render_template("login.html", error=error)

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

# ── Register API blueprint (no login required for API — handled by frontend) ──
app.register_blueprint(api_bp)

@app.route("/")
@login_required
def index():
    return render_template("index.html", username=session.get("username","admin"))


if __name__ == "__main__":
    print("=" * 60)
    print("  Codex Alternus — Alternate History Sandbox")
    print(f"  Running on http://localhost:{FLASK_PORT}")
    print("  Login: admin / admin")
    print("=" * 60)
    app.run(debug=FLASK_DEBUG, port=FLASK_PORT, threaded=True)
