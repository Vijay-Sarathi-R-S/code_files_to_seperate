/**
 * map.js — stub (SVG map removed; world is shown as fictional text description)
 * Kept for backwards compatibility only.
 */
