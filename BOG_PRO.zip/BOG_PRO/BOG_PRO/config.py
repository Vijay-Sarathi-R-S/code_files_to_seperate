"""
config.py – Central configuration with in-memory API key override.
The key can be set at runtime via the /api/config/setkey endpoint,
which overrides whatever is in .env — no file editing required.
"""

import os
from dotenv import load_dotenv

load_dotenv()

GEMINI_MODEL = "gemini-2.5-flash"
TEMPERATURE  = 1.0          # max allowed by langchain-google-genai SDK
FLASK_PORT   = int(os.getenv("FLASK_PORT", 5000))
FLASK_DEBUG  = os.getenv("FLASK_DEBUG", "true").lower() == "true"

# In-memory key store — set via /api/config/setkey at runtime
# Takes priority over .env
_runtime_api_key: str = ""


def set_runtime_key(key: str) -> None:
    """Store an API key set by the user through the browser UI."""
    global _runtime_api_key
    _runtime_api_key = key.strip()


def get_api_key() -> str:
    """Return the active API key: runtime override first, then .env."""
    return _runtime_api_key or os.getenv("GEMINI_API_KEY", "").strip()


def get_llm(temperature: float = TEMPERATURE):
    """
    Return a configured ChatGoogleGenerativeAI LLM instance.
    Raises a clear EnvironmentError if no valid key is configured.
    """
    from langchain_google_genai import ChatGoogleGenerativeAI

    key = get_api_key()
    if not key or key == "paste_your_gemini_api_key_here":
        raise EnvironmentError("NO_API_KEY")

    return ChatGoogleGenerativeAI(
        model=GEMINI_MODEL,
        google_api_key=key,
        temperature=temperature,
        convert_system_message_to_human=True,
    )
