/**
 * main.js — Codex Alternus — Redesigned UI
 * Binds to the new dark command-center HTML structure.
 */

// ─────────────────────────────────────────────────────────────────
// API
// ─────────────────────────────────────────────────────────────────
const API = {
  async post(url, body) {
    const r = await fetch(url, {
      method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(body)
    });
    return r.json();
  },
  async get(url) { return (await fetch(url)).json(); }
};

// ─────────────────────────────────────────────────────────────────
// Error helper — opens Settings automatically on key errors
// ─────────────────────────────────────────────────────────────────
function handleApiError(data, fallbackTitle="Error") {
  const err = (data?.error || "").toString();
  if (err === "NO_API_KEY" || err === "API_KEY_INVALID") {
    const msg = data.message || "Your Gemini API key is invalid or missing.";
    toast("⚙ API Key Required", msg, "error", 12000);
    openSettings();
    return true;
  }
  toast(fallbackTitle, data?.message || data?.error || "Unknown error.", "error", 8000);
  return false;
}

// ─────────────────────────────────────────────────────────────────
// Settings Modal
// ─────────────────────────────────────────────────────────────────
async function openSettings() {
  document.getElementById("settings-overlay").classList.add("open");
  try {
    const s = await API.get("/api/config/status");
    const b = document.getElementById("key-banner");
    b.innerHTML = s.has_key
      ? `<div class="key-ok">✅ Key active: <code>${esc(s.key_preview)}</code></div>`
      : `<div class="key-miss">⚠ No valid API key. Enter one below.</div>`;
  } catch(_) {}
}
function closeSettings() {
  document.getElementById("settings-overlay").classList.remove("open");
}
async function saveApiKey() {
  const key = document.getElementById("api-key-input").value.trim();
  if (!key) { toast("Empty Key","Paste your Gemini API key.","error"); return; }
  const r = await API.post("/api/config/setkey", { api_key: key });
  if (r.success) {
    toast("Key Saved","API key activated. Forge your world!","success",6000);
    closeSettings();
  } else {
    toast("Error", r.error||"Could not save key.", "error");
  }
}

// ─────────────────────────────────────────────────────────────────
// Loading Veil
// ─────────────────────────────────────────────────────────────────
function showLoading(msg) {
  document.getElementById("lv-msg").textContent = msg || "Consulting the AI agents…";
  document.getElementById("loading-veil").classList.remove("hidden");
}
function hideLoading() {
  document.getElementById("loading-veil").classList.add("hidden");
}
function setBusy(busy) {
  document.querySelectorAll(".btn-accent,.btn-secondary,.btn-ghost")
    .forEach(b => b.disabled = busy);
}

// ─────────────────────────────────────────────────────────────────
// Step unlock
// ─────────────────────────────────────────────────────────────────
function unlockSteps() {
  document.getElementById("step2").classList.remove("locked");
  document.getElementById("step3").classList.remove("locked");
}

// ─────────────────────────────────────────────────────────────────
// Create Scenario
// ─────────────────────────────────────────────────────────────────
async function createScenario() {
  const input = document.getElementById("scenario-input").value.trim();
  if (!input) { toast("Empty","Describe your scenario first.","error"); return; }
  showLoading("The Scenario Architect is forging your alternate world…");
  setBusy(true);
  try {
    const data = await API.post("/api/scenario/create", { user_input: input });
    if (!data.success) { handleApiError(data, "Forge Failed"); return; }
    updateDisplay(data.world);
    unlockSteps();
    toast("World Forged", `"${esc(data.scenario?.title||'World')}" is now active.`, "success", 7000);
  } catch(e) {
    toast("Error", e.message, "error");
  } finally { hideLoading(); setBusy(false); }
}

// ─────────────────────────────────────────────────────────────────
// Apply Event
// ─────────────────────────────────────────────────────────────────
async function applyEvent() {
  const name = document.getElementById("event-name").value.trim();
  const desc = document.getElementById("event-desc").value.trim();
  if (!name || !desc) { toast("Missing Fields","Provide both a title and description.","error"); return; }
  showLoading(`All 5 AI agents deliberate on "${name}"…`);
  setBusy(true);
  try {
    const data = await API.post("/api/event/apply", { event_name:name, event_description:desc });
    if (!data.success) { handleApiError(data, "Event Failed"); return; }
    updateDisplay(data.current_state);
    toast("History Rewritten", `"${name}" has altered this timeline.`, "success", 7000);
    if (data.consequences && !data.consequences.error) {
      showConsequenceModal(name, data.consequences, data.npc_actions, data.chronicle);
    }
  } catch(e) {
    toast("Error", e.message, "error");
  } finally { hideLoading(); setBusy(false); }
}

// ─────────────────────────────────────────────────────────────────
// What-If
// ─────────────────────────────────────────────────────────────────
async function simulateWhatIf() {
  const q = document.getElementById("whatif-input").value.trim();
  if (!q) { toast("Empty","Ask a question first.","error"); return; }
  showLoading("The Oracle gazes into alternate streams of time…");
  setBusy(true);
  try {
    const data = await API.post("/api/whatif", { question: q });
    if (!data.success) { handleApiError(data, "Oracle Silent"); return; }
    showWhatIfModal(q, data);
  } catch(e) {
    toast("Error", e.message, "error");
  } finally { hideLoading(); setBusy(false); }
}

// ─────────────────────────────────────────────────────────────────
// Advance Turn
// ─────────────────────────────────────────────────────────────────
async function advanceTurn() {
  const years = parseInt(document.getElementById("yr-num").value)||1;
  showLoading(`${years} year(s) flow past… AI agents act in the shadows…`);
  setBusy(true);
  try {
    const data = await API.post("/api/turn/advance", { years });
    if (!data.success) { handleApiError(data, "Time Frozen"); return; }
    updateDisplay(data.current_state);
    toast("Time Flows", `${years} year(s) have passed.`, "info", 5000);
    if (data.npc_actions?.npc_decisions?.length) showNPCModal(data.npc_actions, data.chronicle);
  } catch(e) {
    toast("Error", e.message, "error");
  } finally { hideLoading(); setBusy(false); }
}

// ─────────────────────────────────────────────────────────────────
// NPC Actions
// ─────────────────────────────────────────────────────────────────
async function getNPCActions() {
  showLoading("AI figures deliberate in the shadows of the realm…");
  setBusy(true);
  try {
    const data = await API.post("/api/npc/actions", {});
    if (!data.success) { handleApiError(data, "Silent Figures"); return; }
    showNPCModal(data.npc_actions);
    toast("Agents Speak","Autonomous decisions rendered.","info",5000);
  } catch(e) {
    toast("Error", e.message, "error");
  } finally { hideLoading(); setBusy(false); }
}

// ─────────────────────────────────────────────────────────────────
// Load Scenario Map — AI identifies real countries, Leaflet displays them
// ─────────────────────────────────────────────────────────────────
async function loadScenarioMap() {
  const btn    = document.getElementById("btn-load-map");
  const status = document.getElementById("map-status");

  if (btn) btn.disabled = true;
  if (status) status.textContent = "Asking AI to identify real-world countries…";

  // Ensure map is initialised
  if (typeof initMap === "function") initMap();

  try {
    // First, get the map analysis from the prompt
    const scenarioInput = document.getElementById("scenario-input");
    if (scenarioInput && scenarioInput.value.trim()) {
      const prompt = scenarioInput.value.trim();
      
      // Call the analyze-prompt endpoint
      const analysisResponse = await fetch('/analyze-prompt', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          prompt: prompt,
          current_map: 'world'
        })
      });
      
      const analysisData = await analysisResponse.json();
      
      if (analysisData.success && analysisData.analysis) {
        // Update map with analysis
        if (typeof updateMapForPrompt === "function") {
          updateMapForPrompt(analysisData.analysis);
        }
      }
    }
    
    // Then try to get country data from /api/map/identify
    const data = await API.post("/api/map/identify", {});
    if (!data.success) {
      handleApiError(data, "Map Error");
      if (status) status.textContent = "Map identification failed.";
      return;
    }

    const countries = data.countries || [];
    const withGeo   = countries.filter(c => c.geo);

    if (typeof renderMapCountries === "function") {
      renderMapCountries(countries);
    }

    if (withGeo.length) {
      const summary = withGeo.map(c =>
        `${c.fictional_name} → ${c.real_name}`
      ).join(" · ");
      if (status) status.textContent = summary;
      toast("Map Loaded", `${withGeo.length} countries identified & highlighted.`, "success", 6000);
    } else {
      if (status) status.textContent = "No geographic data found for this scenario's nations.";
    }
  } catch(e) {
    if (status) status.textContent = "Map error: " + e.message;
    toast("Map Error", e.message, "error");
  } finally {
    if (btn) btn.disabled = false;
  }
}

// ─────────────────────────────────────────────────────────────────
// Reset
// ─────────────────────────────────────────────────────────────────
async function resetWorld() {
  if (!confirm("Erase all history and start over?")) return;
  await API.post("/api/world/reset", {});
  clearDisplay();
  document.getElementById("step2").classList.add("locked");
  document.getElementById("step3").classList.add("locked");
  document.getElementById("chronicle-feed").innerHTML = `
    <div class="start-state">
      <div class="ss-glyph">⚜</div>
      <div class="ss-title">The Codex Awaits</div>
      <div class="ss-body">Complete <strong>Step 1</strong> to forge a new world.</div>
    </div>`;
  toast("Reset","World erased. Begin anew.","info",4000);
}

// ─────────────────────────────────────────────────────────────────
// Update Display
// ─────────────────────────────────────────────────────────────────
function updateDisplay(state) {
  if (!state) return;
  const sc = state.scenario || {};
  const wc = state.world_conditions || {};

  // Topbar HUD
  const hud = document.getElementById("tb-hud");
  if (sc.title) {
    hud.innerHTML = `<div class="hud-pill">
      <span class="hud-name">${esc(sc.title)}</span>
      <span class="hud-sep">|</span>
      <span class="hud-year">${esc(sc.current_year||"—")}</span>
      <span class="hud-sep">|</span>
      <span class="hud-turn">Turn ${state.turn||0}</span>
    </div>`;
  }

  // Vital stats
  setStat("sv-stability", wc.political_stability);
  setStat("sv-economy",   wc.global_economy);
  setStat("sv-tech",      wc.technological_level);
  setStat("sv-ideology",  wc.dominant_ideology);
  setEl("sv-conflicts", (wc.major_conflicts||[]).join(", ")||"—");
  setEl("sv-social",    wc.social_climate||"—");

  // World overview (text, no map)
  renderWorldOverview(sc, state.countries||[], wc);

  // Lists
  renderNations(state.countries||[]);
  renderNPCs(state.npcs||[]);
  renderFactions(state.factions||[]);

  // Chronicle
  renderChronicle(state.chronicle||[]);
}

function setStat(id, val) {
  const el = document.getElementById(id);
  if (!el) return;
  el.textContent = val||"—";
  el.className = "stat-v long";
  if (!val) return;
  const v = val.toLowerCase();
  if (v.match(/stable|thriving|growing/))    el.classList.add("v-stable");
  else if (v.match(/tense|stagnant/))         el.classList.add("v-moderate");
  else if (v.match(/volatile|declining/))     el.classList.add("v-volatile");
  else if (v.match(/crisis|collapsed/))       el.classList.add("v-crisis");
}
function setEl(id, val) { const e=document.getElementById(id); if(e) e.textContent=val; }

function clearDisplay() {
  document.getElementById("tb-hud").innerHTML = `<div class="hud-empty">No world active — begin at Step 1</div>`;
  ["sv-stability","sv-economy","sv-tech","sv-ideology","sv-conflicts","sv-social"]
    .forEach(id => { const e=document.getElementById(id); if(e){e.textContent="—";e.className="stat-v long";} });
  document.getElementById("world-overview").innerHTML = `<p class="no-data">No world active.</p>`;
  document.getElementById("nations-list").innerHTML   = `<p class="no-data">None yet.</p>`;
  document.getElementById("npcs-list").innerHTML      = `<p class="no-data">None yet.</p>`;
  document.getElementById("factions-list").innerHTML  = `<p class="no-data">None yet.</p>`;
  setEl("n-count",""); setEl("f-count",""); setEl("fc-count","");
}

// ─────────────────────────────────────────────────────────────────
// World Overview (text description — no SVG map)
// ─────────────────────────────────────────────────────────────────
function renderWorldOverview(sc, countries, wc) {
  const el = document.getElementById("world-overview");
  if (!sc.title) { el.innerHTML=`<p class="no-data">No world active.</p>`; return; }
  el.innerHTML = `
    <p><strong>${esc(sc.title)}</strong> — ${esc(sc.setting||"")}</p>
    ${sc.summary ? `<p>${esc(sc.summary)}</p>` : ""}
    <p><em>Divergence point:</em> ${esc(sc.divergence_point||"—")}</p>
    <p><em>Known nations:</em> ${esc(countries.map(c=>c.name).join(", ")||"—")}</p>
    ${wc.dominant_ideology ? `<p><em>The age is defined by</em> ${esc(wc.dominant_ideology)}.</p>` : ""}
  `;
}

// ─────────────────────────────────────────────────────────────────
// Render Lists
// ─────────────────────────────────────────────────────────────────
function renderNations(nations) {
  const el = document.getElementById("nations-list");
  setEl("n-count", nations.length ? `(${nations.length})` : "");
  if (!nations.length) { el.innerHTML=`<p class="no-data">None yet.</p>`; return; }
  el.innerHTML = nations.map(n => `
    <div class="w-card">
      <div class="wc-header">
        <div class="wc-name">
          <span class="nation-dot" style="background:${esc(n.color_code||'#886622')};border-radius:2px"></span>
          ${esc(n.name)}
        </div>
        <span class="wc-badge" style="background:rgba(232,160,32,0.1);color:var(--amber-l);border:1px solid rgba(232,160,32,0.2)">
          ${esc(n.military_strength||"—")}
        </span>
      </div>
      <div class="wc-detail">🏛 ${esc(n.capital||"—")} · ${esc(n.government||"—")}</div>
      <div class="wc-detail">💰 ${esc(n.economy||"—")}</div>
      ${n.description ? `<div class="wc-note">${esc(trunc(n.description,70))}</div>` : ""}
    </div>`).join("");
}

function renderNPCs(npcs) {
  const el = document.getElementById("npcs-list");
  setEl("f-count", npcs.length ? `(${npcs.length})` : "");
  if (!npcs.length) { el.innerHTML=`<p class="no-data">None yet.</p>`; return; }
  el.innerHTML = npcs.map(n => {
    const t = (n.threat_level||"low").toLowerCase();
    return `<div class="w-card">
      <div class="wc-header">
        <div class="wc-name">${esc(n.name)}</div>
        <span class="wc-badge threat-${t}">${esc(n.threat_level||"low")}</span>
      </div>
      <div class="wc-detail">${esc(n.role||"—")} · ${esc(n.country||"—")}</div>
      ${n.goal ? `<div class="wc-note">${esc(trunc(n.goal,65))}</div>` : ""}
    </div>`;
  }).join("");
}

function renderFactions(factions) {
  const el = document.getElementById("factions-list");
  setEl("fc-count", factions.length ? `(${factions.length})` : "");
  if (!factions.length) { el.innerHTML=`<p class="no-data">None yet.</p>`; return; }
  el.innerHTML = factions.map(f => {
    const inf = (f.influence||"low").toLowerCase().replace(/\s+/,"-");
    return `<div class="w-card">
      <div class="wc-header">
        <div class="wc-name">${esc(f.name)}</div>
        <span class="wc-badge inf-${inf}">${esc(f.influence||"—")}</span>
      </div>
      <div class="wc-detail">${esc(f.type||"—")}</div>
      ${f.goal ? `<div class="wc-note">${esc(trunc(f.goal||f.description||"",65))}</div>` : ""}
    </div>`;
  }).join("");
}

// ─────────────────────────────────────────────────────────────────
// Chronicle
// ─────────────────────────────────────────────────────────────────
function renderChronicle(entries) {
  const feed = document.getElementById("chronicle-feed");
  if (!entries.length) {
    feed.innerHTML=`<div class="start-state"><div class="ss-glyph">⚜</div>
      <div class="ss-title">The Codex Awaits</div>
      <div class="ss-body">Create a scenario to begin writing history.</div></div>`;
    return;
  }
  const typeMap = {opening:"opening",event:"event",turn_advance:"turn",what_if:"what_if"};
  const labelMap= {opening:"Opening",event:"Event",turn:"Era",what_if:"What-If"};
  feed.innerHTML = [...entries].reverse().map(e => {
    const cls   = typeMap[e.type]||"event";
    const label = labelMap[cls]||"Record";
    const pars  = (e.entry||"").split(/\n+/).filter(p=>p.trim()).map(p=>`<p>${esc(p.trim())}</p>`).join("");
    return `<div class="chr-entry">
      <div class="chr-top">
        <span class="chr-meta">Turn ${e.turn||0} · Year ${e.year||"—"}</span>
        <span class="chr-badge badge-${cls}">${label}</span>
      </div>
      ${e.chronicle_title ? `<div class="chr-title">${esc(e.chronicle_title)}</div>` : ""}
      <div class="chr-prose">${pars||`<p>${esc(e.entry||"")}</p>`}</div>
      ${e.historical_verdict ? `<div class="chr-verdict">"${esc(e.historical_verdict)}"</div>` : ""}
      ${e.notable_quote ? `<div class="chr-quote">
        <div class="chr-quote-text">"${esc(e.notable_quote.quote||"")}"</div>
        <div class="chr-quote-speaker">— ${esc(e.notable_quote.speaker||"")}</div>
      </div>` : ""}
    </div>`;
  }).join("");
}

// ─────────────────────────────────────────────────────────────────
// Modal: Consequences
// ─────────────────────────────────────────────────────────────────
function showConsequenceModal(eventName, cons, npcActions, chronicle) {
  const imm  = cons.immediate_consequences || {};
  const med  = cons.medium_term  || {};
  const lng  = cons.long_term    || {};
  const npcs = (npcActions?.npc_decisions) || [];
  const chron= chronicle?.chronicle_entry || "";

  document.getElementById("modal-content").innerHTML = `
    <h2>⚔ ${esc(eventName)}</h2>
    <div class="divider">— — —</div>

    ${chron ? `<h3>📜 Chronicle</h3>
    ${chron.split(/\n+/).filter(p=>p).map(p=>`<p>${esc(p.trim())}</p>`).join("")}` : ""}

    <h3>⚡ Immediate Consequences</h3>
    <div class="m-block">
      ${["Political","Economic","Military","Social"].map(k =>
        imm[k.toLowerCase()] ? `<p><strong>${k}:</strong> ${esc(imm[k.toLowerCase()])}</p>` : ""
      ).join("")}
    </div>

    ${med.narrative ? `<h3>⏳ The Next Decade</h3>
    ${med.narrative.split(/\n+/).filter(p=>p).map(p=>`<p>${esc(p.trim())}</p>`).join("")}
    ${(med.key_developments||[]).length ? `<ul>${med.key_developments.map(d=>`<li>${esc(d)}</li>`).join("")}</ul>`:""}` : ""}

    ${(lng.possible_futures||[]).length ? `<h3>🌌 Possible Futures</h3>
    ${lng.possible_futures.map(f=>`<div class="m-block">
      <div class="m-label">${esc(f.name||"")} — ${esc(f.probability||"")} probability</div>
      <p>${esc(f.description||"")}</p>
    </div>`).join("")}` : ""}

    ${(lng.butterfly_effects||[]).length ? `<h3>🦋 Butterfly Effects</h3>
    <ul>${lng.butterfly_effects.map(b=>`<li>${esc(b)}</li>`).join("")}</ul>` : ""}

    ${npcs.length ? `<h3>👑 Agent Decisions</h3>
    ${npcs.map(d=>`<div class="npc-m">
      <div class="npc-m-name">${esc(d.npc_name||"")}</div>
      <div class="npc-m-role">${esc(d.role||"")} · ${esc(d.country||"")}</div>
      <div class="npc-m-act">▸ ${esc(d.decision||"")}</div>
      ${d.dialogue ? `<div class="npc-m-quote">"${esc(d.dialogue)}"</div>` : ""}
      <div class="npc-m-mood">${esc(d.mood||"")}</div>
    </div>`).join("")}` : ""}

    ${(cons.player_opportunities||[]).length ? `<h3>🌟 Your Opportunities</h3>
    <ul>${cons.player_opportunities.map(o=>`<li>${esc(o)}</li>`).join("")}</ul>` : ""}
  `;
  openModal();
}

// ─────────────────────────────────────────────────────────────────
// Modal: NPC
// ─────────────────────────────────────────────────────────────────
function showNPCModal(npcActions, chronicle) {
  const decisions = npcActions?.npc_decisions || [];
  const emergent  = npcActions?.emergent_event || null;
  const chron     = chronicle?.chronicle_entry || "";
  document.getElementById("modal-content").innerHTML = `
    <h2>👑 Agent Decisions</h2>
    <div class="divider">— — —</div>
    ${chron ? `<h3>📜 Chronicle</h3>${chron.split(/\n+/).filter(p=>p).map(p=>`<p>${esc(p.trim())}</p>`).join("")}` : ""}
    ${decisions.map(d=>`<div class="npc-m">
      <div class="npc-m-name">${esc(d.npc_name||"")}</div>
      <div class="npc-m-role">${esc(d.role||"")} · ${esc(d.country||"")}</div>
      <div class="npc-m-act">▸ ${esc(d.decision||"")}</div>
      ${d.dialogue ? `<div class="npc-m-quote">"${esc(d.dialogue)}"</div>` : ""}
      ${d.reasoning ? `<p style="font-size:12px;color:var(--text-dim);margin-top:6px"><em>${esc(d.reasoning)}</em></p>` : ""}
      <div class="npc-m-mood">${esc(d.mood||"")}</div>
    </div>`).join("")||`<p>No decisions this turn.</p>`}
    ${emergent ? `<h3>⚡ Emergent Event <span style="font-size:10px;opacity:.6">${esc(emergent.severity||"")}</span></h3>
    <div class="m-block"><div class="m-label">${esc(emergent.title||"")}</div><p>${esc(emergent.description||"")}</p></div>` : ""}
  `;
  openModal();
}

// ─────────────────────────────────────────────────────────────────
// Modal: What-If
// ─────────────────────────────────────────────────────────────────
function showWhatIfModal(question, data) {
  const cons  = data.consequences || {};
  const chron = data.speculative_chronicle || {};
  const imm   = cons.immediate_consequences || {};
  const med   = cons.medium_term  || {};
  const lng   = cons.long_term    || {};
  document.getElementById("modal-content").innerHTML = `
    <h2>🔮 What-If Oracle</h2>
    <div class="m-block" style="border-color:rgba(144,96,208,0.4)">
      <div class="m-label">The Question</div>
      <p style="color:var(--purple-l)">${esc(question)}</p>
    </div>
    ${chron.historical_verdict ? `<p style="text-align:center;color:var(--purple-l);font-style:italic">"${esc(chron.historical_verdict)}"</p>` : ""}
    ${chron.chronicle_entry ? `<h3>📜 Speculative Chronicle</h3>
    ${chron.chronicle_entry.split(/\n+/).filter(p=>p).map(p=>`<p>${esc(p.trim())}</p>`).join("")}` : ""}

    <h3>⚡ Immediate Consequences</h3>
    <div class="m-block">
      ${Object.entries(imm).map(([k,v])=>`<p><strong>${k}:</strong> ${esc(v)}</p>`).join("")}
    </div>
    ${med.narrative ? `<h3>⏳ The Next Decade</h3>${med.narrative.split(/\n+/).filter(p=>p).map(p=>`<p>${esc(p.trim())}</p>`).join("")}` : ""}
    ${(lng.possible_futures||[]).length ? `<h3>🌌 Possible Futures</h3>
    ${lng.possible_futures.map(f=>`<div class="m-block">
      <div class="m-label">${esc(f.name||"")} — ${esc(f.probability||"")} probability</div>
      <p>${esc(f.description||"")}</p>
    </div>`).join("")}` : ""}
    ${(lng.butterfly_effects||[]).length ? `<h3>🦋 Butterfly Effects</h3><ul>${lng.butterfly_effects.map(b=>`<li>${esc(b)}</li>`).join("")}</ul>` : ""}
    ${(cons.player_opportunities||[]).length ? `<h3>🌟 What You Could Do</h3><ul>${cons.player_opportunities.map(o=>`<li>${esc(o)}</li>`).join("")}</ul>` : ""}
  `;
  openModal();
}

// ─────────────────────────────────────────────────────────────────
// Modal open/close
// ─────────────────────────────────────────────────────────────────
function openModal()  { document.getElementById("result-overlay").classList.add("open"); }
function closeModal() { document.getElementById("result-overlay").classList.remove("open"); }

// ─────────────────────────────────────────────────────────────────
// Toast
// ─────────────────────────────────────────────────────────────────
function toast(title, msg, type="info", ms=5000) {
  const c = document.getElementById("toasts");
  const t = document.createElement("div");
  t.className = `toast t-${type}`;
  t.innerHTML = `<div class="toast-title">${esc(title)}</div>${esc(msg)}`;
  t.onclick   = () => t.remove();
  c.appendChild(t);
  setTimeout(()=>t.remove(), ms);
}

// ─────────────────────────────────────────────────────────────────
// Utilities
// ─────────────────────────────────────────────────────────────────
function esc(s) {
  return String(s||"")
    .replace(/&/g,"&amp;").replace(/</g,"&lt;")
    .replace(/>/g,"&gt;").replace(/"/g,"&quot;");
}
function trunc(s, n) { return s&&s.length>n ? s.slice(0,n)+"…" : s||""; }

// ─────────────────────────────────────────────────────────────────
// Init — restore state if server already has a scenario loaded
// ─────────────────────────────────────────────────────────────────
async function init() {
  try {
    const data = await API.get("/api/world/state");
    if (data.success && data.initialized) {
      updateDisplay(data.state);
      unlockSteps();
    }
  } catch(_) { /* fresh start */ }
  hideLoading();
}
window.addEventListener("DOMContentLoaded", init);
