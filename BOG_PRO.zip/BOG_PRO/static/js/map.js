/**
 * map.js — Codex Alternus Real Map
 * Uses Leaflet.js + OpenStreetMap tiles.
 * AI identifies real-world countries for scenario nations,
 * then displays them on an interactive map with their scenario colors.
 */

/* global L */

let _map = null;   // Leaflet map instance
let _markers = [];     // current marker layers
let _polygons = [];     // current rectangle layers
let _worldGeo = null;   // cached world GeoJSON
let _geoLayer = null;   // current GeoJSON layer

const GEOJSON_URL =
  "https://raw.githubusercontent.com/datasets/geo-countries/master/data/countries.geojson";

// ─────────────────────────────────────────────────────────────────
// Auto-initialize when DOM is ready
// ─────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM loaded, initializing map from map.js...');
    initMap();
});

// ─────────────────────────────────────────────────────────────────
// Init map — called once when the map div is ready
// ─────────────────────────────────────────────────────────────────
function initMap() {
  const el = document.getElementById("leaflet-map");
  if (!el) {
    console.error("Map container element #leaflet-map not found!");
    return;
  }
  if (_map) {
    console.log("Map already initialized");
    return;
  }

  console.log("Creating map instance...");
  _map = L.map("leaflet-map", {
    center: [20, 0],
    zoom: 2,
    minZoom: 1,
    maxZoom: 10,
    zoomControl: true,
    attributionControl: true,
  });

  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
    maxZoom: 19,
  }).addTo(_map);

  console.log("Map initialized successfully");

  // Force a resize after a short delay to ensure proper rendering
  setTimeout(() => {
    if (_map) {
      _map.invalidateSize();
      console.log("Map size invalidated");
    }
  }, 300);

  // Load world GeoJSON in background for polygon highlighting
  _loadWorldGeoJSON();
  
  // Update map status
  const mapStatus = document.getElementById("map-status");
  if (mapStatus) {
    mapStatus.innerHTML = '<i class="fas fa-check-circle" style="color:#4ade80"></i> Map ready';
  }
}

// ─────────────────────────────────────────────────────────────────
// Load world GeoJSON (once, cached)
// ─────────────────────────────────────────────────────────────────
async function _loadWorldGeoJSON() {
  try {
    console.log("Loading world GeoJSON...");
    const r = await fetch(GEOJSON_URL);
    _worldGeo = await r.json();
    console.log("[Map] World GeoJSON loaded:", _worldGeo.features.length, "countries");
    
    // After loading, optionally reset map with base layer
    resetMap();
  } catch(e) {
    console.warn("[Map] Could not load world GeoJSON:", e.message);
  }
}

// ─────────────────────────────────────────────────────────────────
// Clear all map layers
// ─────────────────────────────────────────────────────────────────
function clearMapLayers() {
  _markers.forEach(m => {
    if (m && m.remove) m.remove();
  });
  _markers = [];
  
  _polygons.forEach(p => {
    if (p && p.remove) p.remove();
  });
  _polygons = [];
  
  if (_geoLayer) { 
    _geoLayer.remove(); 
    _geoLayer = null; 
  }
}

// ─────────────────────────────────────────────────────────────────
// Render countries returned by /api/map/identify
// ─────────────────────────────────────────────────────────────────
function renderMapCountries(geoData) {
  if (!_map) {
    console.warn("Map not initialized, initializing now...");
    initMap();
    setTimeout(() => renderMapCountries(geoData), 500);
    return;
  }

  clearMapLayers();

  // Filter valid countries
  const validCountries = Array.isArray(geoData) ? geoData.filter(c => c && c.geo) : [];
  
  if (!validCountries.length) {
    showMapMessage("No geographic data available for this scenario.");
    return;
  }

  const bounds = [];
  const boundsArray = [];

  // --- Method 1: GeoJSON polygon highlight (if world GeoJSON loaded) ---
  const iso2Set = new Set(validCountries.map(c => c.iso2 ? c.iso2.toUpperCase() : null).filter(Boolean));
  const colorMap = {};
  validCountries.forEach(c => { 
    if (c.iso2) colorMap[c.iso2.toUpperCase()] = c; 
  });

  if (_worldGeo && _worldGeo.features) {
    _geoLayer = L.geoJSON(_worldGeo, {
      style: (feature) => {
        if (!feature || !feature.properties) return {};
        
        const code = (feature.properties.ISO_A2 || feature.properties.iso_a2 || "").toUpperCase();
        if (iso2Set.has(code) && colorMap[code]) {
          const c = colorMap[code];
          return {
            fillColor: c.color || "#c8931a",
            fillOpacity: 0.45,
            color: _lighten(c.color || "#c8931a"),
            weight: 2,
            opacity: 1,
          };
        }
        return {
          fillColor: "#111620",
          fillOpacity: 0.3,
          color: "#2a3550",
          weight: 0.5,
          opacity: 0.6,
        };
      },
      onEachFeature: (feature, layer) => {
        if (!feature || !feature.properties) return;
        
        const code = (feature.properties.ISO_A2 || feature.properties.iso_a2 || "").toUpperCase();
        if (iso2Set.has(code) && colorMap[code]) {
          const c = colorMap[code];
          layer.bindTooltip(
            `<div style="font-family:Rajdhani,sans-serif;font-size:13px;font-weight:600;color:#f0c060">
               ${_esc(c.fictional_name || c.real_name)}
             </div>
             <div style="font-size:11px;color:#9aaccc">Real: ${_esc(c.real_name || 'Unknown')}</div>`,
            { sticky: true, className: "map-tooltip" }
          );
          
          // Add box bounds for fitting
          if (c.geo && c.geo.bbox) {
            const b = c.geo.bbox;
            if (Array.isArray(b) && b.length === 4) {
              boundsArray.push([b[0], b[1], b[2], b[3]]);
              bounds.push(L.latLngBounds([b[0], b[2]], [b[1], b[3]]));
            }
          }
        }
      },
    }).addTo(_map);
    _polygons.push(_geoLayer);
  }

  // --- Method 2: Bounding-box rectangles (fallback / supplement) ---
  validCountries.forEach(c => {
    if (!c.geo) return;
    
    const bbox = c.geo.bbox;
    if (bbox && Array.isArray(bbox) && bbox.length === 4) {
      const rect = L.rectangle(
        [[bbox[0], bbox[2]], [bbox[1], bbox[3]]],
        {
          color: c.color || "#c8931a",
          fillColor: c.color || "#c8931a",
          fillOpacity: _worldGeo ? 0 : 0.25,   // invisible if GeoJSON already shown
          weight: _worldGeo ? 0 : 2,
          opacity: 0.6, 
          dashArray: "4 3",
        }
      ).addTo(_map);
      _polygons.push(rect);
      
      // Add to bounds
      bounds.push(L.latLngBounds([bbox[0], bbox[2]], [bbox[1], bbox[3]]));
    }

    // Marker for nation capital / label
    if (c.geo.lat && c.geo.lon) {
      const marker = L.circleMarker([c.geo.lat, c.geo.lon], {
        radius: 6,
        fillColor: c.color || "#c8931a",
        color: "#ffffff",
        weight: 2,
        fillOpacity: 0.9,
      }).addTo(_map);

      marker.bindPopup(`
        <div style="font-family:Cinzel,serif;font-size:14px;color:#e8a020;margin-bottom:4px">
          ${_esc(c.fictional_name || c.real_name)}
        </div>
        <div style="font-family:Rajdhani,sans-serif;font-size:12px;color:#d4dbe8">
          Real-world equivalent: <strong>${_esc(c.real_name || 'Unknown')}</strong>
        </div>`, {
        maxWidth: 220,
        className: "map-popup",
      });

      _markers.push(marker);
    }
  });

  // Fit map to all countries
  if (bounds.length > 0) {
    try {
      const group = new L.featureGroup(bounds);
      _map.fitBounds(group.getBounds(), { padding: [30, 30], maxZoom: 6 });
    } catch(e) {
      console.warn("Could not fit bounds:", e);
      _map.setView([20, 0], 2);
    }
  } else if (validCountries.length > 0 && validCountries[0].geo && validCountries[0].geo.lat && validCountries[0].geo.lon) {
    // Fallback: center on first country
    _map.setView([validCountries[0].geo.lat, validCountries[0].geo.lon], 5);
  }
  
  // Update map status
  const mapStatus = document.getElementById("map-status");
  if (mapStatus) {
    mapStatus.innerHTML = `<i class="fas fa-check-circle" style="color:#4ade80"></i> Showing ${validCountries.length} nation(s)`;
  }
}

// ─────────────────────────────────────────────────────────────────
// Show a centered message on the map (used when no geo data)
// ─────────────────────────────────────────────────────────────────

// Add this function to map.js after the existing functions

// ─────────────────────────────────────────────────────────────────
// Improved map centering based on country detection
// ─────────────────────────────────────────────────────────────────
function centerMapOnCountry(countryCode, countryName) {
    if (!_map) {
        initMap();
        setTimeout(() => centerMapOnCountry(countryCode, countryName), 500);
        return;
    }
    
    // Country coordinates database (as fallback)
    const countryCoordinates = {
        'US': [39.8283, -98.5795, 4],
        'IN': [20.5937, 78.9629, 5],
        'GB': [55.3781, -3.4360, 5],
        'FR': [46.2276, 2.2137, 5],
        'DE': [51.1657, 10.4515, 5],
        'JP': [36.2048, 138.2529, 5],
        'CN': [35.8617, 104.1954, 4],
        'RU': [61.5240, 105.3188, 3],
        'BR': [-14.2350, -51.9253, 4],
        'AU': [-25.2744, 133.7751, 4],
        'CA': [56.1304, -106.3468, 3],
        'MX': [23.6345, -102.5528, 5],
        'IT': [41.8719, 12.5674, 5],
        'ES': [40.4637, -3.7492, 5],
        'EG': [26.8206, 30.8025, 5],
        'ZA': [-30.5595, 22.9375, 5],
        'AR': [-38.4161, -63.6167, 4],
        'KR': [35.9078, 127.7669, 5],
        'ID': [-0.7893, 113.9213, 4],
        'TR': [38.9637, 35.2433, 5]
    };
    
    let coordinates;
    
    // Try to get coordinates from GeoJSON first
    if (_worldGeo && _worldGeo.features) {
        const country = _worldGeo.features.find(f => 
            f.properties.ISO_A2 === countryCode || 
            f.properties.iso_a2 === countryCode
        );
        
        if (country && country.properties) {
            // Calculate center from bounds
            const bounds = L.geoJSON(country).getBounds();
            const center = bounds.getCenter();
            coordinates = [center.lat, center.lng, 5];
        }
    }
    
    // Fallback to database
    if (!coordinates && countryCoordinates[countryCode]) {
        coordinates = countryCoordinates[countryCode];
    }
    
    // Default to country name search if all else fails
    if (!coordinates) {
        // Try to find by name in GeoJSON
        if (_worldGeo && _worldGeo.features) {
            const country = _worldGeo.features.find(f => 
                f.properties.ADMIN && 
                f.properties.ADMIN.toLowerCase().includes(countryName.toLowerCase())
            );
            
            if (country) {
                const bounds = L.geoJSON(country).getBounds();
                const center = bounds.getCenter();
                coordinates = [center.lat, center.lng, 5];
            }
        }
    }
    
    if (coordinates) {
        const [lat, lon, zoom] = coordinates;
        _map.setView([lat, lon], zoom);
        
        // Add a pulsing marker
        addRegionMarker(lat, lon, countryName);
        
        // Update HUD
        const hud = document.getElementById("tb-hud");
        if (hud) {
            hud.innerHTML = `<div class="hud-content">
                <i class="fas fa-map-marker-alt" style="color:#ffd966"></i>
                <span>${countryName}</span>
            </div>`;
        }
        
        // Update status
        const mapStatus = document.getElementById("map-status");
        if (mapStatus) {
            mapStatus.innerHTML = `<i class="fas fa-check-circle" style="color:#4ade80"></i> Centered on: ${countryName}`;
        }
        
        return true;
    }
    
    return false;
}

// ─────────────────────────────────────────────────────────────────
// Update the existing updateMapForPrompt function
// ─────────────────────────────────────────────────────────────────
function updateMapForPrompt(analysis) {
    if (!_map) {
        initMap();
        setTimeout(() => updateMapForPrompt(analysis), 500);
        return;
    }
    
    if (analysis) {
        // If we have a country code, use the improved centering
        if (analysis.country_code && centerMapOnCountry(analysis.country_code, analysis.primary_region)) {
            // Successfully centered using country code
        } 
        // Otherwise use coordinates if available
        else if (analysis.coordinates && analysis.coordinates.length === 3) {
            const [lat, lon, zoom] = analysis.coordinates;
            _map.setView([lat, lon], zoom);
            
            // Add marker
            addRegionMarker(lat, lon, analysis.primary_region || 'Region');
            
            // Update HUD
            const hud = document.getElementById("tb-hud");
            if (hud) {
                hud.innerHTML = `<div class="hud-content">
                    <i class="fas fa-map-marker-alt" style="color:#ffd966"></i>
                    <span>${analysis.primary_region || 'World'}</span>
                    ${analysis.historical_period && analysis.historical_period !== 'unspecified' ? 
                      `<span style="margin-left:10px;font-size:11px;color:#9ca3af">${analysis.historical_period}</span>` : ''}
                </div>`;
            }
            
            // Update status
            const mapStatus = document.getElementById("map-status");
            if (mapStatus) {
                mapStatus.innerHTML = `<i class="fas fa-check-circle" style="color:#4ade80"></i> Showing: ${analysis.primary_region || 'World'}`;
            }
        }
        
        // Show analysis badge
        const badge = document.getElementById("mapAnalysisBadge");
        const text = document.getElementById("mapAnalysisText");
        if (badge && text) {
            text.innerHTML = `${analysis.primary_region || 'World'} (${Math.round((analysis.confidence || 0.5) * 100)}% confidence)`;
            badge.classList.add('show');
            
            setTimeout(() => {
                badge.classList.remove('show');
            }, 5000);
        }
    }
}

// Export the new function
window.centerMapOnCountry = centerMapOnCountry;

function showMapMessage(msg) {
  const el = document.getElementById("map-msg");
  if (el) { 
    el.textContent = msg; 
    el.style.display = "block"; 
  }
  setTimeout(() => { 
    const e = document.getElementById("map-msg"); 
    if(e) e.style.display = "none"; 
  }, 5000);
}

// ─────────────────────────────────────────────────────────────────
// Reset map to world overview
// ─────────────────────────────────────────────────────────────────
function resetMap() {
  if (!_map) {
    initMap();
    return;
  }
  
  clearMapLayers();
  _map.setView([20, 0], 2);
  
  // Reload base GeoJSON with grey countries
  if (_worldGeo && _worldGeo.features && _map) {
    _geoLayer = L.geoJSON(_worldGeo, {
      style: { 
        fillColor: "#111620", 
        fillOpacity: 0.4, 
        color: "#2a3550", 
        weight: 0.5 
      }
    }).addTo(_map);
    _polygons.push(_geoLayer);
  }
  
  // Update map status
  const mapStatus = document.getElementById("map-status");
  if (mapStatus) {
    mapStatus.innerHTML = '<i class="fas fa-globe" style="color:#ffd966"></i> World view';
  }
}

// ─────────────────────────────────────────────────────────────────
// Update map based on AI prompt analysis
// ─────────────────────────────────────────────────────────────────
function updateMapForPrompt(analysis) {
  if (!_map) {
    initMap();
    setTimeout(() => updateMapForPrompt(analysis), 500);
    return;
  }
  
  if (analysis && analysis.coordinates && analysis.coordinates.length === 3) {
    const [lat, lon, zoom] = analysis.coordinates;
    _map.setView([lat, lon], zoom);
    
    // Update HUD
    const hud = document.getElementById("tb-hud");
    if (hud) {
      hud.innerHTML = `<div class="hud-content">
        <i class="fas fa-map-marker-alt" style="color:#ffd966"></i>
        <span>${analysis.primary_region || 'World'}</span>
        ${analysis.historical_period && analysis.historical_period !== 'unspecified' ? 
          `<span style="margin-left:10px;font-size:11px;color:#9ca3af">${analysis.historical_period}</span>` : ''}
      </div>`;
    }
    
    // Show analysis badge
    const badge = document.getElementById("mapAnalysisBadge");
    const text = document.getElementById("mapAnalysisText");
    if (badge && text) {
      text.innerHTML = `${analysis.primary_region || 'World'} (${Math.round((analysis.confidence || 0.5) * 100)}% confidence)`;
      badge.classList.add('show');
      
      setTimeout(() => {
        badge.classList.remove('show');
      }, 5000);
    }
    
    // Add marker
    addRegionMarker(lat, lon, analysis.primary_region || 'Region');
    
    // Update status
    const mapStatus = document.getElementById("map-status");
    if (mapStatus) {
      mapStatus.innerHTML = `<i class="fas fa-check-circle" style="color:#4ade80"></i> Showing: ${analysis.primary_region || 'World'}`;
    }
  }
}

// ─────────────────────────────────────────────────────────────────
// Add a pulsing marker for region
// ─────────────────────────────────────────────────────────────────
function addRegionMarker(lat, lon, regionName) {
  if (!_map) return;
  
  // Remove existing region markers
  if (window._regionMarker) {
    _map.removeLayer(window._regionMarker);
  }
  
  // Create custom marker
  const customIcon = L.divIcon({
    className: 'region-marker',
    html: '<div style="background:rgba(255,217,102,0.3);border:2px solid #ffd966;border-radius:50%;width:30px;height:30px;animation:pulse 2s infinite;"></div>',
    iconSize: [30, 30],
    iconAnchor: [15, 15]
  });
  
  window._regionMarker = L.marker([lat, lon], { icon: customIcon })
    .bindPopup(`<b>${regionName}</b><br>Primary region detected`)
    .addTo(_map);
}

// ─────────────────────────────────────────────────────────────────
// Handle window resize
// ─────────────────────────────────────────────────────────────────
window.addEventListener('resize', function() {
  if (_map) {
    _map.invalidateSize();
  }
});

// ─────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────
function _esc(s) {
  return String(s || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function _lighten(hex) {
  // Simple hex colour lightening for border
  try {
    if (!hex) return "#c8931a";
    
    hex = hex.replace("#", "");
    if (hex.length === 3) hex = hex.split("").map(c => c + c).join("");
    
    const r = Math.min(255, parseInt(hex.slice(0, 2), 16) + 60);
    const g = Math.min(255, parseInt(hex.slice(2, 4), 16) + 60);
    const b = Math.min(255, parseInt(hex.slice(4, 6), 16) + 60);
    
    return `#${r.toString(16).padStart(2, "0")}${g.toString(16).padStart(2, "0")}${b.toString(16).padStart(2, "0")}`;
  } catch(_) { 
    return "#c8931a"; 
  }
}

// Export functions for use in main.js
window.initMap = initMap;
window.renderMapCountries = renderMapCountries;
window.resetMap = resetMap;
window.updateMapForPrompt = updateMapForPrompt;