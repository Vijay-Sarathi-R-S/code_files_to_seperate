"""
app.py – Flask application entry point with session-based login and intelligent map rendering.
Credentials: admin / admin
"""

from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from flask_cors import CORS
from routes.api import api_bp
from routes.map_api import map_bp
import functools
import google.generativeai as genai
import json
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configure Gemini AI
GEMINI_API_KEY = os.getenv('GEMINI_API_KEY', '')
if GEMINI_API_KEY:
    genai.configure(api_key=GEMINI_API_KEY)

# Configuration - define these if not in config.py
FLASK_PORT = 5000
FLASK_DEBUG = True

app = Flask(__name__)
app.secret_key = "codex-alternus-secret-2024"
CORS(app)

# ── Auth ─────────────────────────────────────────────────────────
VALID_USERS = {"admin": "admin"}

def login_required(f):
    @functools.wraps(f)
    def decorated(*args, **kwargs):
        if not session.get("logged_in"):
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated

@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()
        if VALID_USERS.get(username) == password:
            session["logged_in"] = True
            session["username"] = username
            return redirect(url_for("index"))
        error = "Invalid username or password."
    return render_template("login.html", error=error)

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

# ── Intelligent Map Analysis Route (IMPROVED with max_tokens) ──────────────────
@app.route("/analyze-prompt", methods=["POST"])
@login_required
def analyze_prompt():
    """
    Analyze user prompt to determine which map to display
    """
    try:
        data = request.json
        prompt = data.get('prompt', '').lower()
        current_map = data.get('current_map', 'world')
        
        # Get API key from request header or session
        api_key = request.headers.get('X-API-Key') or session.get('gemini_api_key') or GEMINI_API_KEY
        
        # If we have an API key, use Gemini for analysis
        if api_key:
            try:
                # Configure Gemini with the available key
                genai.configure(api_key=api_key)
                model = genai.GenerativeModel(
                    'gemini-2.0-flash',
                    generation_config={
                        "max_output_tokens": 2500,
                        "temperature": 0.2,
                    }
                )
                
                # Use Gemini to analyze the prompt - IMPROVED PROMPT
                analysis_prompt = f"""
                You are a geographic location detector. Analyze this user prompt about alternate history and determine which geographic region/country should be displayed on a map.

                User Prompt: "{prompt}"
                Current Map View: {current_map}

                Return a JSON response with:
                1. primary_region: The main country/region mentioned (use full country names like "United States", "India", "United Kingdom")
                2. country_code: ISO 3166-1 alpha-2 country code if it's a specific country (e.g., "US", "IN", "GB", "FR")
                3. map_type: Type of map needed ("world", "country", "region", "city")
                4. coordinates: [latitude, longitude, zoom] for the map view
                5. historical_period: Any historical period mentioned
                6. confidence: Confidence score (0-1)
                7. reasoning: Brief explanation of your choice

                COORDINATE REFERENCE:
                - United States: [39.8283, -98.5795, 4]
                - India: [20.5937, 78.9629, 5]
                - United Kingdom: [55.3781, -3.4360, 5]
                - France: [46.2276, 2.2137, 5]
                - Germany: [51.1657, 10.4515, 5]
                - Japan: [36.2048, 138.2529, 5]
                - China: [35.8617, 104.1954, 4]
                - Russia: [61.5240, 105.3188, 3]
                - Brazil: [-14.2350, -51.9253, 4]
                - Australia: [-25.2744, 133.7751, 4]
                - Europe: [50.0, 10.0, 4]
                - Asia: [34.0479, 100.6197, 3]
                - Africa: [8.7832, 34.5085, 3]
                - Middle East: [26.0, 45.0, 4]
                - South America: [-14.2350, -51.9253, 3]
                - World: [20.0, 0.0, 2]

                Examples:
                - If prompt mentions "What if India had become a superpower in 1947", return primary_region: "India", country_code: "IN", coordinates: [20.5937, 78.9629, 5]
                - If prompt mentions "United States Civil War alternate outcome", return primary_region: "United States", country_code: "US", coordinates: [39.8283, -98.5795, 4]
                - If prompt mentions "Roman Empire never fell", return primary_region: "Europe", coordinates: [41.9028, 12.4964, 5]

                Return ONLY valid JSON. No other text.
                """
                
                response = model.generate_content(analysis_prompt)
                
                # Parse the response
                response_text = response.text
                # Clean markdown if present
                if '```json' in response_text:
                    response_text = response_text.split('```json')[1].split('```')[0]
                elif '```' in response_text:
                    response_text = response_text.split('```')[1].split('```')[0]
                
                map_analysis = json.loads(response_text.strip())
                
            except Exception as e:
                print(f"Gemini analysis failed, using enhanced fallback: {e}")
                map_analysis = enhanced_rule_based_map_analysis(prompt, current_map)
        else:
            # No API key, use enhanced rule-based analysis
            map_analysis = enhanced_rule_based_map_analysis(prompt, current_map)
        
        # Store the analyzed region in session
        session['last_analyzed_region'] = map_analysis.get('primary_region')
        session['last_map_coordinates'] = map_analysis.get('coordinates', [20.0, 0.0, 2])
        
        return jsonify({
            'success': True,
            'analysis': map_analysis
        })
        
    except Exception as e:
        print(f"Error analyzing prompt: {e}")
        return jsonify({
            'success': True,  # Return true with fallback
            'analysis': enhanced_rule_based_map_analysis(prompt, current_map)
        })

def enhanced_rule_based_map_analysis(prompt: str, current_map: str) -> dict:
    """Enhanced fallback rule-based map analysis with better country detection"""
    prompt_lower = prompt.lower()
    
    # Comprehensive country and region database
    regions = {
        # United States and variations
        'united states': {
            'primary_region': 'United States',
            'country_code': 'US',
            'map_type': 'country',
            'coordinates': [39.8283, -98.5795, 4],
            'confidence': 0.95,
            'keywords': ['united states', 'usa', 'u.s.a.', 'america', 'american', 'us', 'u.s.']
        },
        'india': {
            'primary_region': 'India',
            'country_code': 'IN',
            'map_type': 'country',
            'coordinates': [20.5937, 78.9629, 5],
            'confidence': 0.95,
            'keywords': ['india', 'indian', 'bharat', 'hindustan', 'delhi', 'mumbai', 'gandhi']
        },
        'united kingdom': {
            'primary_region': 'United Kingdom',
            'country_code': 'GB',
            'map_type': 'country',
            'coordinates': [55.3781, -3.4360, 5],
            'confidence': 0.95,
            'keywords': ['united kingdom', 'uk', 'britain', 'british', 'england', 'london', 'great britain']
        },
        'france': {
            'primary_region': 'France',
            'country_code': 'FR',
            'map_type': 'country',
            'coordinates': [46.2276, 2.2137, 5],
            'confidence': 0.95,
            'keywords': ['france', 'french', 'paris', 'napoleon']
        },
        'germany': {
            'primary_region': 'Germany',
            'country_code': 'DE',
            'map_type': 'country',
            'coordinates': [51.1657, 10.4515, 5],
            'confidence': 0.95,
            'keywords': ['germany', 'german', 'berlin', 'prussia']
        },
        'japan': {
            'primary_region': 'Japan',
            'country_code': 'JP',
            'map_type': 'country',
            'coordinates': [36.2048, 138.2529, 5],
            'confidence': 0.95,
            'keywords': ['japan', 'japanese', 'tokyo', 'kyoto']
        },
        'china': {
            'primary_region': 'China',
            'country_code': 'CN',
            'map_type': 'country',
            'coordinates': [35.8617, 104.1954, 4],
            'confidence': 0.95,
            'keywords': ['china', 'chinese', 'beijing', 'shanghai']
        },
        'russia': {
            'primary_region': 'Russia',
            'country_code': 'RU',
            'map_type': 'country',
            'coordinates': [61.5240, 105.3188, 3],
            'confidence': 0.95,
            'keywords': ['russia', 'russian', 'moscow', 'soviet']
        },
        'brazil': {
            'primary_region': 'Brazil',
            'country_code': 'BR',
            'map_type': 'country',
            'coordinates': [-14.2350, -51.9253, 4],
            'confidence': 0.95,
            'keywords': ['brazil', 'brazilian']
        },
        'australia': {
            'primary_region': 'Australia',
            'country_code': 'AU',
            'map_type': 'country',
            'coordinates': [-25.2744, 133.7751, 4],
            'confidence': 0.95,
            'keywords': ['australia', 'australian']
        },
        'canada': {
            'primary_region': 'Canada',
            'country_code': 'CA',
            'map_type': 'country',
            'coordinates': [56.1304, -106.3468, 3],
            'confidence': 0.95,
            'keywords': ['canada', 'canadian']
        },
        'mexico': {
            'primary_region': 'Mexico',
            'country_code': 'MX',
            'map_type': 'country',
            'coordinates': [23.6345, -102.5528, 5],
            'confidence': 0.95,
            'keywords': ['mexico', 'mexican']
        },
        'italy': {
            'primary_region': 'Italy',
            'country_code': 'IT',
            'map_type': 'country',
            'coordinates': [41.8719, 12.5674, 5],
            'confidence': 0.95,
            'keywords': ['italy', 'italian', 'rome', 'roman']
        },
        'spain': {
            'primary_region': 'Spain',
            'country_code': 'ES',
            'map_type': 'country',
            'coordinates': [40.4637, -3.7492, 5],
            'confidence': 0.95,
            'keywords': ['spain', 'spanish']
        },
        'egypt': {
            'primary_region': 'Egypt',
            'country_code': 'EG',
            'map_type': 'country',
            'coordinates': [26.8206, 30.8025, 5],
            'confidence': 0.95,
            'keywords': ['egypt', 'egyptian', 'cairo']
        },
        'south africa': {
            'primary_region': 'South Africa',
            'country_code': 'ZA',
            'map_type': 'country',
            'coordinates': [-30.5595, 22.9375, 5],
            'confidence': 0.95,
            'keywords': ['south africa', 'afrikaans']
        },
        'argentina': {
            'primary_region': 'Argentina',
            'country_code': 'AR',
            'map_type': 'country',
            'coordinates': [-38.4161, -63.6167, 4],
            'confidence': 0.95,
            'keywords': ['argentina', 'argentine']
        },
        'south korea': {
            'primary_region': 'South Korea',
            'country_code': 'KR',
            'map_type': 'country',
            'coordinates': [35.9078, 127.7669, 5],
            'confidence': 0.95,
            'keywords': ['south korea', 'korean', 'seoul']
        },
        'indonesia': {
            'primary_region': 'Indonesia',
            'country_code': 'ID',
            'map_type': 'country',
            'coordinates': [-0.7893, 113.9213, 4],
            'confidence': 0.95,
            'keywords': ['indonesia', 'indonesian']
        },
        'turkey': {
            'primary_region': 'Turkey',
            'country_code': 'TR',
            'map_type': 'country',
            'coordinates': [38.9637, 35.2433, 5],
            'confidence': 0.95,
            'keywords': ['turkey', 'turkish', 'ottoman', 'istanbul']
        },
        # Regions
        'europe': {
            'primary_region': 'Europe',
            'map_type': 'region',
            'coordinates': [50.0, 10.0, 4],
            'confidence': 0.85,
            'keywords': ['europe', 'european', 'eu', 'continental']
        },
        'asia': {
            'primary_region': 'Asia',
            'map_type': 'region',
            'coordinates': [34.0479, 100.6197, 3],
            'confidence': 0.85,
            'keywords': ['asia', 'asian', 'far east']
        },
        'africa': {
            'primary_region': 'Africa',
            'map_type': 'region',
            'coordinates': [8.7832, 34.5085, 3],
            'confidence': 0.85,
            'keywords': ['africa', 'african']
        },
        'middle east': {
            'primary_region': 'Middle East',
            'map_type': 'region',
            'coordinates': [26.0, 45.0, 4],
            'confidence': 0.85,
            'keywords': ['middle east', 'arab', 'persian', 'gulf', 'levant']
        },
        'south america': {
            'primary_region': 'South America',
            'map_type': 'region',
            'coordinates': [-14.2350, -51.9253, 3],
            'confidence': 0.85,
            'keywords': ['south america', 'latin america', 'andes']
        },
        'north america': {
            'primary_region': 'North America',
            'map_type': 'region',
            'coordinates': [40.0, -100.0, 3],
            'confidence': 0.85,
            'keywords': ['north america']
        },
        'scandinavia': {
            'primary_region': 'Scandinavia',
            'map_type': 'region',
            'coordinates': [61.0, 15.0, 4],
            'confidence': 0.85,
            'keywords': ['scandinavia', 'nordic', 'sweden', 'norway', 'denmark', 'finland']
        },
        'balkans': {
            'primary_region': 'Balkans',
            'map_type': 'region',
            'coordinates': [42.0, 22.0, 5],
            'confidence': 0.85,
            'keywords': ['balkans', 'yugoslavia', 'serbia', 'croatia']
        }
    }
    
    # Check each region/country for keyword matches
    best_match = None
    highest_confidence = 0
    
    for key, region_data in regions.items():
        # Check if any keyword matches
        for keyword in region_data.get('keywords', [key]):
            if keyword in prompt_lower:
                confidence = region_data['confidence']
                if confidence > highest_confidence:
                    highest_confidence = confidence
                    best_match = region_data.copy()
                    best_match['reasoning'] = f'Detected keyword: "{keyword}"'
                    best_match['historical_period'] = extract_historical_period(prompt)
                break
    
    if best_match:
        return best_match
    
    # Default to world map
    return {
        'primary_region': 'World',
        'map_type': 'world',
        'coordinates': [20.0, 0.0, 2],
        'historical_period': extract_historical_period(prompt),
        'confidence': 0.5,
        'reasoning': 'No specific region detected, showing world map'
    }

def extract_historical_period(prompt: str) -> str:
    """Extract historical period from prompt"""
    prompt_lower = prompt.lower()
    
    periods = {
        'ancient': ['ancient', 'bc', 'bce', 'roman', 'greek', 'egypt', 'persian', 'byzantine', 'classical'],
        'medieval': ['medieval', 'middle ages', 'crusades', 'dark ages', 'feudal', 'knight', 'gothic'],
        'renaissance': ['renaissance', 'reformation', 'elizabethan', 'shakespeare'],
        'colonial': ['colonial', 'empire', 'colonization', 'discovery', 'exploration', 'conquistador', 'imperial'],
        'industrial': ['industrial', 'revolution', '1800s', '19th', 'victorian', 'steam', 'railway'],
        'modern': ['modern', 'ww1', 'ww2', 'world war', 'cold war', '20th', '1914', '1939', '1945', 'nuclear'],
        'future': ['future', '22nd', '2100', 'cyberpunk', 'sci-fi', 'futuristic', '2050', 'space']
    }
    
    for period, keywords in periods.items():
        if any(keyword in prompt_lower for keyword in keywords):
            return period
    
    return 'unspecified'

# ── API endpoint for historical map data (with max_tokens) ─────────────────────────────
@app.route("/historical-map-data", methods=["POST"])
@login_required
def get_historical_map_data():
    """Get historical map data for a specific region and time period"""
    try:
        data = request.json
        region = data.get('region', 'India')
        year = data.get('year', 1900)
        
        api_key = request.headers.get('X-API-Key') or session.get('gemini_api_key') or GEMINI_API_KEY
        
        if api_key:
            genai.configure(api_key=api_key)
            model = genai.GenerativeModel(
                'gemini-2.5-flash',
                generation_config={
                    "max_output_tokens": 2500,
                    "temperature": 0.3,
                }
            )
            
            # Use Gemini to generate historical map data
            prompt = f"""
            Generate historical map data for {region} in the year {year}.
            Include:
            1. Political boundaries and territories
            2. Major cities and their historical names
            3. Important historical sites
            4. Trade routes and connections
            5. Cultural/religious regions
            
            Return as JSON with appropriate geojson structure.
            """
            
            response = model.generate_content(prompt)
            
            return jsonify({
                'success': True,
                'region': region,
                'year': year,
                'map_data': response.text
            })
        else:
            return jsonify({
                'success': False,
                'error': 'No API key available'
            }), 400
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# ── Blueprints ────────────────────────────────────────────────────
app.register_blueprint(api_bp, url_prefix='/api')
app.register_blueprint(map_bp, url_prefix='/map')

# ── Main page ─────────────────────────────────────────────────────
@app.route("/")
@login_required
def index():
    return render_template("index.html", username=session.get("username", "admin"))

if __name__ == "__main__":
    print("=" * 60)
    print("  Codex Alternus — Alternate History Sandbox")
    print(f"  Running on http://localhost:{FLASK_PORT}")
    print("  Login: admin / admin")
    print("  Gemini AI-powered map intelligence enabled")
    print("  Max Tokens: 2500 (configured)")
    print("=" * 60)
    app.run(debug=FLASK_DEBUG, port=FLASK_PORT, threaded=True)