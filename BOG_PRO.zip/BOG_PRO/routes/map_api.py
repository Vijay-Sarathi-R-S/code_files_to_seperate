"""
routes/map_api.py – AI-powered country identification + Nominatim geocoding.
Uses Gemini to map scenario nations to real-world country names,
then returns their ISO-3166 codes and bounding boxes via Nominatim (free, no key).
"""

import json, re
import requests
from flask import Blueprint, request, jsonify
from world_state import world_state
import config as _config

map_bp = Blueprint("map", __name__, url_prefix="/api/map")

NOMINATIM_URL = "https://nominatim.openstreetmap.org/search"
NOMINATIM_HEADERS = {
    "User-Agent": "CodexAlternus/1.0 (alternate-history-sandbox-app)"
}


def _identify_countries_with_ai(scenario_countries: list, scenario_text: str) -> list:
    """
    Ask Gemini to map each fictional/historical nation in the scenario
    to its closest real-world country equivalent.
    Returns a list of dicts: [{fictional, real, iso2, color}]
    """
    llm = _config.get_llm(temperature=0.3)

    names = [c.get("name","") for c in scenario_countries[:6]]
    colors = {c.get("name",""): c.get("color_code","#c8931a") for c in scenario_countries}

    prompt = f"""You are a geographic analyst for an alternate-history game.
Given these fictional/historical nation names from a scenario, identify the closest real-world country equivalent for each.

Scenario context: {scenario_text[:300]}
Nations: {", ".join(names)}

Respond ONLY with a valid JSON array — no markdown:
[
  {{"fictional": "<name from list>", "real": "<real country name in English>", "iso2": "<ISO 3166-1 alpha-2 code e.g. IN, US, FR>"}},
  ...
]

Rules:
- Match each fictional nation to the real country it most resembles geographically/historically
- If a nation spans multiple countries, pick the primary one
- If fictional with no real equivalent, use the nearest region's country
- Always return valid ISO-2 codes"""

    from langchain.prompts import ChatPromptTemplate
    from langchain.schema.output_parser import StrOutputParser
    chain = (
        ChatPromptTemplate.from_messages([("human", "{prompt}")])
        | llm
        | StrOutputParser()
    )
    raw = chain.invoke({"prompt": prompt})
    cleaned = re.sub(r"```(?:json)?", "", raw).strip()
    try:
        mappings = json.loads(cleaned)
    except Exception:
        m = re.search(r"\[.*\]", cleaned, re.DOTALL)
        mappings = json.loads(m.group()) if m else []

    # Attach original color codes
    for item in mappings:
        item["color"] = colors.get(item.get("fictional",""), "#c8931a")
    return mappings


def _get_country_bounds(country_name: str, iso2: str) -> dict | None:
    """
    Query Nominatim to get the bounding box for a country.
    Returns {lat, lon, bbox: [south, north, west, east]} or None.
    """
    try:
        params = {
            "q": country_name,
            "format": "json",
            "limit": 1,
            "featuretype": "country",
            "countrycodes": iso2.lower() if iso2 else "",
        }
        resp = requests.get(NOMINATIM_URL, params=params,
                            headers=NOMINATIM_HEADERS, timeout=8)
        results = resp.json()
        if not results:
            # Retry without countrycodes constraint
            params.pop("countrycodes", None)
            params["q"] = country_name + " country"
            resp = requests.get(NOMINATIM_URL, params=params,
                                headers=NOMINATIM_HEADERS, timeout=8)
            results = resp.json()

        if not results:
            return None

        r = results[0]
        bb = r.get("boundingbox", [])   # [S, N, W, E]
        return {
            "lat": float(r.get("lat", 0)),
            "lon": float(r.get("lon", 0)),
            "display_name": r.get("display_name", country_name),
            "bbox": [float(x) for x in bb] if len(bb)==4 else None,
        }
    except Exception:
        return None


# ── Routes ──────────────────────────────────────────────────────

@map_bp.route("/identify", methods=["POST"])
def identify_countries():
    """
    POST /api/map/identify
    Identifies real-world countries for all scenario nations using AI,
    then fetches their geographic bounding boxes from Nominatim.
    Returns Leaflet-ready data.
    """
    if not world_state.is_initialized():
        return jsonify({"success": False, "error": "No scenario active."}), 400

    snap = world_state.get_snapshot()
    scenario_countries = snap.get("countries", [])
    sc = snap.get("scenario", {})
    scenario_text = f"{sc.get('title','')} {sc.get('setting','')} {sc.get('divergence_point','')}"

    if not scenario_countries:
        return jsonify({"success": False, "error": "No countries in scenario."}), 400

    try:
        # Step 1: AI identifies real-world equivalents
        mappings = _identify_countries_with_ai(scenario_countries, scenario_text)

        # Step 2: Geocode each via Nominatim
        geo_data = []
        for m in mappings:
            bounds = _get_country_bounds(m.get("real",""), m.get("iso2",""))
            geo_data.append({
                "fictional_name": m.get("fictional",""),
                "real_name":      m.get("real",""),
                "iso2":           m.get("iso2",""),
                "color":          m.get("color","#c8931a"),
                "geo":            bounds,
            })

        return jsonify({"success": True, "countries": geo_data})

    except Exception as e:
        msg = str(e)
        if "NO_API_KEY" in msg or "API_KEY_INVALID" in msg or "API key not valid" in msg:
            return jsonify({"success": False, "error": "API_KEY_INVALID",
                            "message": "Set your Gemini API key via ⚙ Settings."}), 503
        return jsonify({"success": False, "error": msg}), 500


@map_bp.route("/geocode", methods=["POST"])
def geocode_country():
    """
    POST /api/map/geocode — { "country": "India" }
    Quick geocode of a single country name (no AI, direct Nominatim).
    """
    data = request.get_json(silent=True) or {}
    country = data.get("country","").strip()
    if not country:
        return jsonify({"success": False, "error": "'country' required"}), 400

    result = _get_country_bounds(country, "")
    if not result:
        return jsonify({"success": False, "error": f"Could not geocode '{country}'"}), 404
    return jsonify({"success": True, "geo": result, "country": country})
